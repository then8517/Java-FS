import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-car-brands',
  templateUrl: './car-brands.component.html',
  styleUrls: ['./car-brands.component.css']
})
export class CarBrandsComponent implements OnInit {

  pro;
  constructor(private p:ProductService) { 
  p.getAll().subscribe((res) => this.pro=res)
  }

  ngOnInit() {
  }

}
