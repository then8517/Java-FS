package com.plp.jdbc.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.plp.jdbc.bean.Banking;
import com.plp.jdbc.bean.Transactions;
import com.plp.jdbc.exception.BankException;

public interface BankDao {
	
	public void accountCreate(Banking bank,Transactions tran) ;
	
	public String balCheck(int accountNo) ;
	
	public String addMoney(int accountNumber,long amount,Transactions tran) ;
	
	public String withdrawMoney(int accountNumber,long amount,Transactions tran);
	
	public HashMap<Integer,Transactions> printTransactions(int  accountId)  ;	

	public String moneyTransfer(int accountNumber01, long amount01, int accountNumber02,Transactions tran1,Transactions tran2) ;


	
}
