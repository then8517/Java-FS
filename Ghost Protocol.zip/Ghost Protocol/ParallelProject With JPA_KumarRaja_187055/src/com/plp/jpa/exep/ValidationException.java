package com.plp.jpa.exep;

public class ValidationException extends Exception{

	String s1;

	public ValidationException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

	
}
