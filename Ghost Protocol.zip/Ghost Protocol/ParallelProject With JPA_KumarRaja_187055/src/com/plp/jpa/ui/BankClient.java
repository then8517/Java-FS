package com.plp.jpa.ui;
import java.util.Scanner;
import com.plp.jpa.entity.Bank;
import com.plp.jpa.exep.ValidationException;
import com.plp.jpa.service.BankService;
import com.plp.jpa.validate.Validator;
public class BankClient {
	public static void main(String args[])
	{
		Bank bank; 
		BankService bankService=new BankService();
		Validator valid = new Validator();
		Scanner scanner = new Scanner(System.in);
		 int choice;
		 while(true)
		 {
			 	System.out.println("-----------------Welcome to xyz bank e-wallet--------------------");
	            System.out.println("please select your option to continue the E-Banking....\n1.Create an Account\n2.Balance Enquiry\n3.Deposit Money\n4.Withdraw Money\n5.Transfer funds\n6.Transaction statement\n7.Exit");
	            choice = scanner.nextInt();
	            switch(choice)
	            {
	            case 1:
	            {
	            	 System.out.println("Please Enter Your Name:");
	                 String name=scanner.next();
	 				try {
						while (!Validator.checkName(name)) {

							System.out.print("Enter your Name:");
							name = scanner.next();
							name += scanner.nextLine();
						}
					} catch (ValidationException e) {
						
						e.printStackTrace();
					}
	                 System.out.println("Enter your 10 digit mobile number:");
	                 String phno=scanner.next();
	                 while(!Validator.checkPhoneNumber(phno))
	                 {
	                	 System.out.print("Enter your 10 digit mobile number: ");
	                	 phno=scanner.next();
	                 }
	                 System.out.println("Enter the amount to be deposited:");
	                 long amt=scanner.nextLong();
	                 int acno = (int)(Math.random()*376485);
	                 System.out.println("Account created Susccessfully!!");
	                 System.out.println("Your Account number is:"+acno);
	                 System.out.println("***********************************");
	                 System.out.println("");
	                 bank=new Bank(acno,name,phno,amt,"\n Account created Successfully.");
	                 bankService.addAccount(bank);
                   break;
	            }
	            case 2:
	            {
	            	System.out.println("Enter Your Account No: ");
	            	int accountNumber=scanner.nextInt();
	            	while(!Validator.checkAccNo(accountNumber))
	            	{
	                	 System.out.print("Enter your account no: ");
	                	 accountNumber=scanner.nextInt();
	            	}
	            	bank=bankService.checkBalance(accountNumber);
	            	System.out.println("Your Account has balance of "+bank.getBalance()+".Rs");
	            	System.out.println("************************************");
	            	System.out.println("");
                   break;
	            }
	            case 3:
	            {
	            	System.out.println("Enter Your Account Number: ");
	            	int accountNumber=scanner.nextInt();
	            	while(!Validator.checkAccNo(accountNumber))
	            	{
	                	 System.out.print("Enter Your Account Number : ");
	                	 accountNumber=scanner.nextInt();
	            	}
	            	System.out.println("Enter the amount tobe deposited: ");
	            	long amount=scanner.nextLong();
	            	bank=bankService.depositMoney(accountNumber,amount,"\n Amount of RS."+amount+" is added to your account");
	            	System.out.println("Your Account is credited with Rs."+amount);
	            	System.out.println("Your Account's Current Balance is Rs."+bank.getBalance());
	            	System.out.println("**************************************");
	            	System.out.println("");
                   break;
	            }
               case 4:
               {
            		System.out.println("Enter Your Account No: ");
	            	int accNumber=scanner.nextInt();
	            	while(!Validator.checkAccNo(accNumber))
	            	{
	                	 System.out.print("Enter your account no: ");
	                	 accNumber=scanner.nextInt();
	            	}
	            	System.out.println("Enter The Amount to be withdrawn: ");
	            	long amnt=scanner.nextLong();
	            	bank=bankService.withdrawMoney(accNumber,amnt,"\n Amount of Rs."+amnt+" is withdrawn from your account");
	            	System.out.println("Your Account is debited with Rs."+amnt);
	            	System.out.println("Your Account's Current Balance is Rs."+bank.getBalance());
	            	System.out.println("*************************************");
	            	System.out.println("");
                   break;
               }
               case 5:
               {
            	    System.out.println("Enter Your Account No: ");
	            	int accNumber1=scanner.nextInt();
	            	while(!Validator.checkAccNo(accNumber1))
	            	{
	                	 System.out.print("Enter your account no: ");
	                	 accNumber1=scanner.nextInt();
	            	}	            	
	            	System.out.println("Enter the amount to Transfer : ");
	            	long amnt=scanner.nextLong();
	            	System.out.println("Enter the receiver account number : ");
	            	int accNumber2=scanner.nextInt();
	            	while(!Validator.checkAccNo(accNumber2))
	            	{
	                	 System.out.print("Enter the receiver account number : ");
	                	 accNumber2=scanner.nextInt();
	            	}	            	
	            	bank=bankService.withdrawMoney(accNumber1,amnt,"Amount of Rs."+amnt+" is debited from your Account");
	            	System.out.println(bank.getBalance());
	            	bank=bankService.depositMoney(accNumber2, amnt,"Amount of RS."+amnt+" is credited to your Acoount");
	            	System.out.println(bank.getBalance());
	            	System.out.println("*************************************");
	            	System.out.println("");
	            	break;  
               }  
               case 6:
               {
            	   System.out.println("Enter Your Account No: ");
            	   int accNumber=scanner.nextInt();
            	   while(!Validator.checkAccNo(accNumber))
	            	{
	                	 System.out.print("Enter your account no: ");
	                	 accNumber=scanner.nextInt();
	            	}	            	
            	   String trans=bankService.getTransactionDetails(accNumber);
            	   System.out.println(trans);
            	   System.out.println("***************************************");
            	   System.out.println("");
                   break;
               }
               case 7:
            	   System.out.println(".........Thank you.........");
            	   scanner.close();
                   System.exit(0);
                   break;
               default: 
                   System.out.println("kindly select the existing options......");
                   break;
	            }
		 }
	}
	
}
