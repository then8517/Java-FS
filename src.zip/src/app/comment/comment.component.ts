import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
member:User;
  constructor(private forumService:ForumService,private router:Router) {
    this.member=new User();
   }

  ngOnInit() {
  }
  postComment(topicId,memberName,commentText,topicName):void {
    this.member.topicId=topicId;
    this.member.topicName=topicName;
    this.member.memberName=memberName;
    this.member.commentText=commentText; 
    this.forumService.postComment(this.member).subscribe(data => {
      this.router.navigate(['/postedcomments'])
    });
}
}
