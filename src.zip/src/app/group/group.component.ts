import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
member:User;
  constructor(private forumService:ForumService,private router:Router) { 
    this.member=new User();
  }
    
  ngOnInit() {
  }
  addGroup(groupName,groupAdmin):void {
    this.member.groupName=groupName;
    this.member.groupAdmin=groupAdmin; 
    this.forumService.addGroup(this.member).subscribe(data => {
      this.router.navigate(['/grouplist'])
    });
}
}
