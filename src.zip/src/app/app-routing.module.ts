import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { GroupComponent } from './group/group.component';
import { TopicComponent } from './topic/topic.component';
import { CommentComponent } from './comment/comment.component';
import { GrouplistComponent } from './grouplist/grouplist.component';
import { TopiclistComponent } from './topiclist/topiclist.component';
import { PostedcommentsComponent } from './postedcomments/postedcomments.component';
import { JoingroupComponent } from './joingroup/joingroup.component';
import { GroupmembersComponent } from './groupmembers/groupmembers.component';
import { SearchmemberComponent } from './searchmember/searchmember.component';


const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'group',component:GroupComponent},
  {path:'topic',component:TopicComponent},
  {path:'comment',component:CommentComponent},
  {path:'grouplist', component:GrouplistComponent},
  {path:'topiclist',component:TopiclistComponent},
  {path:'postedcomments',component:PostedcommentsComponent},
  {path:'joingroup',component:JoingroupComponent},
  {path:'memberlist',component:GroupmembersComponent},
  {path:'searchmember',component:SearchmemberComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
