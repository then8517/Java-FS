import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostedcommentsComponent } from './postedcomments.component';

describe('PostedcommentsComponent', () => {
  let component: PostedcommentsComponent;
  let fixture: ComponentFixture<PostedcommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostedcommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostedcommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
