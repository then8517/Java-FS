import { Component, OnInit } from '@angular/core';
import { ForumService } from '../forum.service';

@Component({
  selector: 'app-postedcomments',
  templateUrl: './postedcomments.component.html',
  styleUrls: ['./postedcomments.component.css']
})
export class PostedcommentsComponent implements OnInit {
comments;
  constructor(private forumService:ForumService) { 
    forumService.postedComments().subscribe((res) => this.comments=res)
  }

  ngOnInit() {
  }

}
