package com.cg.reader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class ReadTrywithResource implements AutoCloseable {
	public static void main(String[] args) throws IOException {
		char[] stmt = new char[100];

		try (Reader reader = new FileReader("readfile.txt");) {
			reader.read(stmt);
			System.out.println(stmt);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub

	}

}