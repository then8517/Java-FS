package com.cg.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;

public class DecPtrnReading implements AutoCloseable {
	public static void main(String[] args) {
	 //    char[] stmt = new char[100];
	 	try (Reader reader = new FileReader("readfile.txt");) {
	 //		
	 		BufferedReader br = new BufferedReader(reader);
	 		
	 		LineNumberReader lnr = new LineNumberReader(reader);
     //		br.read(stmt);
	 		
	 		String stmt = lnr.readLine();
	 		
	 		System.out.println(stmt);
	 		
	 		lnr.mark(1);
	 		System.out.println("Line number 1 marked");

			System.out.println(lnr.skip(1));
			
			
			lnr.reset();
			System.out.println(stmt);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub

	}
}
