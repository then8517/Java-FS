package com.cg.reader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;


public class ReadFromFile {
	public static void main(String[] args) throws IOException  {
		
		char[] stmt = new char[100];
		File file = new File("readfile.txt");
//		System.out.println(file.exists());
//		System.out.println(file.canRead());
		Reader reader = null;
		try {
			reader = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		reader.read(stmt);
		System.out.println(stmt);
	}
}
