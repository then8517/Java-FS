package com.cg.reader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class ReadingInputStreams {
	public static void main(String[] args) throws IOException {
		
		try (InputStream is = new FileInputStream("readfile.txt"))  {
			System.out.println((char)is.read());
			//is.mark(0);
			
			is.skip(1);
			System.out.println("skipping the input");
			System.out.println((char)is.read());
			System.out.println((char)is.read());
			
			System.out.println((char)is.read());
			System.out.println((char)is.read());

//			System.out.println((char)is.read());
//			
//			System.out.println((char)is.read());
			boolean check = is.markSupported();
			
			if(check) {
				is.reset();
				System.out.println((char)is.read());
			}else {
				System.out.println("Not supported");
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
	}
}
