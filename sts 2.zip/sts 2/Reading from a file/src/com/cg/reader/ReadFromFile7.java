package com.cg.reader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class ReadFromFile7 {
	public static void main(String[] args) {

		Path file = Paths.get("readfile.txt");
		try {
			List<String> read = Files.readAllLines(file);
			System.out.println(read);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
