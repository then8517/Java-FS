package com.cg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PreparedStmtExample {
public static void main(String[] args) throws SQLException {
	
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "root");

	
	PreparedStatement ps=con.prepareStatement("INSERT INTO student VALUES(?,?,?)");  
	ps.setInt(1,6012);//1 specifies the first parameter in the query  
	ps.setString(2,"Rajini"); 
	ps.setString(3, "Singh");
	  
	int i = ps.executeUpdate(); 
	System.out.println(+i+" Record(s) inserted");
	
	Statement stmt = con.createStatement();
	ResultSet res = stmt.executeQuery("SELECT * FROM student");
	while(res.next()){
		System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3));

		}
	  
}
}
