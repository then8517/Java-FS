package com.cg.writer;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class WriteToFile implements AutoCloseable{

	public static void main(String[] args) {
		CharSequence stmt = new StringBuffer("Hello World \nWelcome to Java World");
		try(Writer writer = new FileWriter("writefile.txt")){
			writer.append(stmt);
			writer.flush();
			System.out.println(stmt);
		}catch(FileNotFoundException e) {
			e.printStackTrace(); 
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
