package com.cg.serialize;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;


public class SerializingObjects implements Serializable {


	public static void main(String[] args) {
		try {
			Student stud = new Student("Rajesh", 1002); 
			OutputStream is = Files.newOutputStream(Paths.get("serializingfile.txt"));
			ObjectOutputStream oos = new ObjectOutputStream(is);
			
			oos.writeObject(stud);
			oos.flush();
			oos.close();
			System.err.println("Success");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
