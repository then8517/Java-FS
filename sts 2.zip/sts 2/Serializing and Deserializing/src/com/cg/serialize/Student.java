package com.cg.serialize;

import java.io.Serializable;

public class Student implements Serializable {

	 String name;
	 int studID;
	
	public Student() {
		
	}
	public Student(String name, int studID) {
		this.name = name;
		this.studID = studID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getStudID() {
		return studID;
	}
	public void setStudID(int studID) {
		this.studID = studID;
	}
}
