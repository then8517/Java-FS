package com.cg.de_serialize;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.cg.serialize.Student;

public class DeSerializingObjects implements Serializable, AutoCloseable {

	public static void main(String[] args) {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("serializingfile.txt"));) {
			Student stud = (Student) ois.readObject();
			System.out.println("Student name: "+stud.getName()+"\nStudent ID: "+stud.getStudID());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub

	}

}
