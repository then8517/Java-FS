package com.cg.thread;

public class RunnableThread implements Runnable {
	
	@Override
	public void run() {
		System.out.println("Hi");
	}

	public static void main(String[] args) {
		Runnable runnable = new RunnableThread();
		Thread thread = new Thread(runnable);
		thread.start();
	}
}
