package com.cg.thread;

class PutAndGet {
	private int contents;
	private boolean available = false;

	public synchronized void put(int value) {
		while (available == true) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		contents = value;
		available = true;
		notifyAll();
	}

	public synchronized int get() {
		while (available == false) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		available = false;
		notifyAll();
		return contents;
	}
}

class Producer extends Thread {
	private PutAndGet putObj;
	private int number;

	public Producer(PutAndGet putObj, int number) {
		this.putObj = putObj;
		this.number = number;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			putObj.put(i);
			System.out.println("Producer # " + this.number + " put " + i);
		}

	}
}

class Consumer extends Thread {
	private PutAndGet getObj;
	private int number;

	public Consumer(PutAndGet getObj, int number) {
		this.getObj = getObj;
		this.number = number;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			getObj.get();
			System.out.println("Consumer # " + this.number + " got " + i);
		}
	}
}

public class ProducerConsumer {
	public static void main(String[] args) {
		PutAndGet putGetObj = new PutAndGet();
		Producer produce = new Producer(putGetObj, 1);
		Consumer consume = new Consumer(putGetObj, 1);

		produce.start();
		consume.start();
	}

}
