package com.cg.thread;

public class ThreadLock extends Thread {
	final static String resource1 = "The resource 1";
	final static String resource2 = "The resource 2";

	static Thread thread1 = new Thread() {
		public void run() {

			synchronized (resource1) {
				System.out.println(Thread.currentThread().getName() + " locked resource 1");
				try {
					Thread.sleep(500);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
			}

			synchronized (resource2) {
				System.out.println(Thread.currentThread().getName() + " locked resource 2");
				try {
					Thread.sleep(500);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
			}
		}
	};

	static Thread thread2 = new Thread() {
		public void run() {

			synchronized (resource1) {
				System.out.println(Thread.currentThread().getName() + " locked resource 1");
				try {
					Thread.sleep(500);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
			}

			synchronized (resource2) {
				System.out.println(Thread.currentThread().getName() + " locked resource 2");
				try {
					Thread.sleep(500);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
			}
		}
	};

	public static void main(String[] args) {
		thread1.start();
		thread2.start();
	}

}
