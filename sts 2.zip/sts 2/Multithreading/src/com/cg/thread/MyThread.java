package com.cg.thread;

import java.util.concurrent.TimeUnit;
class MyThreadDemo extends Thread{
	public void run() {
		try {
			for (int i = 0; i < 2; i++) {
				TimeUnit.SECONDS.sleep(3);;
				System.out.println("Hello, I am in "+Thread.currentThread().getName());
			}
			}catch (InterruptedException ie) {
				ie.printStackTrace();
			}
	}
}
public class MyThread extends Thread {
	
	public void run() {
		try {
		for (int i = 0; i < 2; i++) {
			TimeUnit.SECONDS.sleep(3);;
			System.out.println("Hi, I am in "+Thread.currentThread().getName());
		}
		}catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	public static void main(String[] args) {
		MyThread thread = new MyThread();
		MyThreadDemo demoThread = new MyThreadDemo();
		thread.start();
		demoThread.start();
		System.out.println("Welcome, I am in "+Thread.currentThread().getName());
	}

}
