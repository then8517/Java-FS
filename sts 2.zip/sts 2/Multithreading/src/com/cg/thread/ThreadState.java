package com.cg.thread;

public class ThreadState extends Thread {
	public void run() {
		try {
			sleep(1);
			for (int i = 10; i > 0; i--)
				;
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	public static void main(String[] args) {
		ThreadState thread = new ThreadState();
		System.out.println(thread.getState());
		thread.start();

		while (true) {
			Thread.State state = thread.getState();
			System.out.println(state);
			if (state == Thread.State.TERMINATED)
				break;
		}
	}

}
