package com.cg.hiding;

public class VariableHiding {
	private String message = "This is an instance variable";

	public VariableHiding() {
		String message = "This is a constructor variable";
		System.out.println(message);
	}

	public void localVariableHiding() {
		String message = "This is a local variable";
		System.out.println(message);
	}

	public void instanceVariableHiding() {
		String message = "This is a local variable";
		System.out.println(this.message);
	}

	public static void main(String[] args) {
		VariableHiding obj = new VariableHiding();
		obj.localVariableHiding();
		obj.instanceVariableHiding();

	}
}
