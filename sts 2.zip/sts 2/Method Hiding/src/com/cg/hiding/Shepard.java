package com.cg.hiding;

public class Shepard extends Dog {
	public static void bark() {
		System.out.println("Shepard barks loud");
	}
	public static void main(String[] args) {
		Shepard.bark();
	}

}
/*Hiding doesn't work like overriding, because static methods are not polymorphic. 
 * Overriding occurs only with instance methods. 
 * It supports late binding, so which method will be called is determined at runtime.
 * On the other hand, method hiding works with static ones. 
 * Therefore it's determined at compile time.*/