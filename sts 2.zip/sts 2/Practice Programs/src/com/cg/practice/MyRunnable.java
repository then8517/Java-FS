package com.cg.practice;

public class MyRunnable implements Runnable {

	public static void main(String[] args) {
		Runnable target = new MyRunnable();
		Thread myThread = new Thread(target);
	}

	 public void run() {
		// TODO Auto-generated method stub		
	}

}
