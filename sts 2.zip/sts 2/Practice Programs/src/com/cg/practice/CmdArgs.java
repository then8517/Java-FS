package com.cg.practice;

public class CmdArgs {

	public static void main(String[] args) {
		if(args.length<1) {
			System.out.println("No args provided");
		}
		else {
			for(String values: args) {
				System.out.println(values);
			}
		}
	}

}
