package com.cg.string;

public class EqualityInStrings {

	public static void main(String[] args) {
		String string1 = new String("I Love Java");
		String string2 = "I Love Java";
		
		System.out.println(string1 == string2);  //Checks for the object
		System.out.println(string1.equals(string2)); //Checks for the letter-by-letter value in a string
		
		String string3 = string1.intern();   //Intern() gives the canonical form of string.
		String string4 = string2.intern();  //It makes the exact copy of a string and helps in check for equality
		System.out.println(string3 == string4);
		System.out.println(string3.equals(string4));
	}

}
