package com.cg.loop;

public class WhileLoop {

	public static void main(String[] args) throws InterruptedException {
		int number=0;
//		while(number == 0) {
//			System.out.println("While Loop starts"); //Loop continues infinitely
//		}
		while(number < 10) {
			System.out.println(number+" Infinite While loop starts");
			number++;
			Thread.sleep(500);
		}
	}

}
