package com.cg.loop;

public class WhileAndForLoop {
	static int number = 0;
	
	public static void forLoop() {
		//For Loop
		for(number = 0; number < 10; number++) {
			System.out.println(number+" In For Loop");
		}
	}
	 
	public static void whileLoop() {
		//While Loop
		while(number < 10) {
			System.out.println(number+" In while loop");
			number++;
		}
	}
public static void main(String[] args) {
	WhileAndForLoop.whileLoop();
	WhileAndForLoop.forLoop();
	
}
}
