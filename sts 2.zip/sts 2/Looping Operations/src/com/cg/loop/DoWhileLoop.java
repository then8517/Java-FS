package com.cg.loop;

public class DoWhileLoop {
	public static void main(String[] args) {
		int number = 10;
		do {
			number *= 2;
			System.out.println(number);
		}while(number <100);
	}

}
