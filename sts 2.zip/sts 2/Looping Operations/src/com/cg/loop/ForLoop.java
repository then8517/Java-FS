package com.cg.loop;

public class ForLoop {
public static void main(String[] args) {
	for(int number = 0; number < 10; number++) {
		System.out.println(number+ " In ForLoop Class");
	}
}
}
