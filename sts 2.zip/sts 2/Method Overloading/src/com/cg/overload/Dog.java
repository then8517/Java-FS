package com.cg.overload;

public class Dog {
	void bark() {
		System.out.println("lol");
	}

	void bark(int number) {
		for (int i = 0; i < 6; i++) {
			System.out.print("lol ");
		}
	}

	public static void main(String[] args) {
		Dog dogObj = new Dog();
		dogObj.bark();
		dogObj.bark(5);
	}
}
