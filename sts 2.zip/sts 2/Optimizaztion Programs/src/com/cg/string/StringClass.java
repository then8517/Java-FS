package com.cg.string;

public class StringClass {

	public static void main(String[] args) throws InterruptedException{
		for(int i=0; i<500; i++) {
			System.out.println("Hi");
			Thread.sleep(1000);
		}

	}

}
