package com.cg.override;

public class Shepard extends Dog {
	public void bark() {
		System.out.println("Shepard barks loud");
	}
	public void run() {
		System.out.println("Shepard runs faster");
	}
	public static void main(String[] args) {
		Shepard shepardObj = new Shepard();
		
		Dog dogObj = new Shepard();
		
		Dog dogObj1 = new Dog();
		
		shepardObj.bark();                                          //Shepard barks loud
		shepardObj.run();                                           //Shepard runs faster 
		
		dogObj.bark();                                              //Shepard barks loud
	
		//	dogObj.run();                                           Dog class does not have run() method in it
		
		dogObj1.bark();                                             //All Dogs have the habit of barking
		
	}
}
