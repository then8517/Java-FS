package com.cg.override;

public class Dog {
	public void bark() {
		System.out.println("All Dogs have the habit of barking");
	}
}
