package stepdef;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep {
	WebDriver driver;
	Actions action;
	LoginPage login;

	@Given("^user is on comedy website$")
	public void user_is_on_comedy_website() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\LAVGOLLA\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("C:\\Users\\LAVGOLLA\\bddSelenium\\ComedyShow\\src\\main\\resources\\ComedyShow.html");

		login = new LoginPage(driver);
		// login.LoginDetails();
		// throw new PendingException();
	}
	@When("^user enters the \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	
	Assert.assertEquals(driver.getTitle(), "Add ComedyShow Form");
	login.LoginDetails(arg1);
	
	Assert.assertNotNull(arg1);
	login.submit();
	driver.switchTo().alert().accept();
	Thread.sleep(500);
    driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);

	//login.reset();
	
	
	login.title(arg2);
	login.submit();
	Assert.assertNotNull(arg2);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	//login.reset();
	
	login.Release(arg3);
	login.submit();
	Assert.assertNotNull(arg3);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	//login.reset();
	
	login.comedian(arg4);
	login.submit();
	Assert.assertNotNull(arg4);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	//login.reset();
	
	login.duration(arg5);
	login.submit();
	Assert.assertNotNull(arg5);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	//login.reset();
	
	login.language(arg6);
	login.submit();
	Assert.assertNotNull(arg6);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	//login.reset();
	
	login.Rating(arg7);
	login.submit();
	Assert.assertNotNull(arg7);
	driver.switchTo().alert().accept();
	Thread.sleep(500);
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	login.reset();
	}

	@When("^user clicks on Add ComedyShow$")
	public void user_clicks_on_Add_ComedyShow() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
		login.submit();
		//driver.close();
	}

	@Then("^successfully logged page must appear$")
	public void successfully_logged_page_must_appear() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
		driver.switchTo().alert().accept();
	//	login.reset();
	}

}
