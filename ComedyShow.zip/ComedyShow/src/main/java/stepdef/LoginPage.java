package stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginPage {

	@FindBy(xpath = "//*[@id=\'Text24\']")
	WebElement ShowId;

	@FindBy(xpath = "//*[@id=\'Text1\']")
	WebElement title;

	@FindBy(xpath = "//*[@id=\'Text12\']")
	WebElement ReleasedDate;

	@FindBy(xpath = "//*[@id=\'Text14\']")
	WebElement comedian;

	@FindBy(xpath = "//*[@id=\'Text15\']")
	WebElement duration;

	@FindBy(xpath = "//*[@id=\'Select12\']")
	WebElement language;

	@FindBy(xpath = "//*[@id=\'Select9\']")
	WebElement Rating;
	
	@FindBy(xpath ="//*[@id=\'Button4\']")
	WebElement Submit;
	
	@FindBy(xpath = "//*[@id=\'Button5\']")
	WebElement reset;

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void LoginDetails(String s) {
		ShowId.sendKeys(s);
	}
	public void title(String s) {
		title.sendKeys(s);
	}
	public void Release(String s) {
		ReleasedDate.sendKeys(s);
	}
	public void comedian(String s) {
		comedian.sendKeys(s);
	}
	public void duration(String s) {
		duration.sendKeys(s);
		
	}
	public void language(String s) {
		Select select = new Select(language);
		select.selectByValue(s);
	}
	public void Rating(String s) {
		Select select1 = new Select(Rating);
		select1.selectByValue(s);

	}
	public void submit() {
		Submit.click();
	}
	public void reset() {
		reset.click();
	}

}
