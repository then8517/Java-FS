package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletForm
 */
@WebServlet("/ServletForm")
public class ServletForm extends HttpServlet {
//	private RequestDispatcher html;
//	 public void init(ServletConfig config) throws ServletException
//	    {
//	        ServletContext context = config.getServletContext();
//	        html = context.getRequestDispatcher("/WEB-INF/index.html");
//	    }
//	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String n=req.getParameter("userName");  
	    String p=req.getParameter("userPass");  
	          
	    if(p.equals("servlet")){  
	        RequestDispatcher rd=req.getRequestDispatcher("servlet2");  
	        rd.forward(req, res);  
	    }  
	    else{       
	        RequestDispatcher rd=req.getRequestDispatcher("/index.html");  
	        System.out.println( "Sorry UserName or Password Error!" );
	        rd.include(req, res);  
	                      
	        }  
	}
//	public void doPost(HttpServletRequest request, HttpServletResponse response)
//		      throws ServletException, IOException {
//
//		      doGet(request, response);
//		   }
}
