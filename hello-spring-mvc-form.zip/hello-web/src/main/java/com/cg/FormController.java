package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class FormController {

	@RequestMapping(method = RequestMethod.GET, value = "/form")
	public String showForm() {
		String view = "form";
		return view;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/form")
	public String submitForm(@ModelAttribute(value = "person") Person person) {

		System.out.println(person);
		
		String view = "form";
		return view;
	}
	
	@ModelAttribute(value = "person")
	public Person createPerson(){
		return new Person();
		
	}
	
	
	
	
	
	
	
	
	
	
}
