package com.cg.order;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ConfigClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("order-product");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Products prodObj1 = new Products();
		prodObj1.setProductName("Iron rod");
		prodObj1.setProductDesc("Fixed size and stable strength");
		prodObj1.setCategory("Iron");
		prodObj1.setWholesalePrice(6987);
		
		Set<Products> products = new HashSet<Products>();
		products.add(prodObj1);
		
		Orders orderObj1 = new Orders();
		orderObj1.setCustomerNumber(234);
		orderObj1.setEmployeeId(507);
		orderObj1.setOrderDate("12-08-2020");
		orderObj1.setShipDate("19-08-2020");
		
		
		Set<Orders> orders = new HashSet<Orders>();
		orders.add(orderObj1);
		
		orderObj1.setProduct(products);	
		
		em.persist(orderObj1);
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}