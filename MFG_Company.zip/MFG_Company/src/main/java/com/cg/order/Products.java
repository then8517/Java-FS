package com.cg.order;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Product_Details") 
public class Products {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "product_number")
	private int productNumber;
	
	@Column(name = "product_name", length=50)
	private String productName;
	
	@Column(name = "product_desc", length=50)
	private String productDesc;
	
	@Column(name = "category", length=50)
	private String category;
	
	@Column(name = "wholesale_price", length=50)
	private int wholesalePrice;
	
	@ManyToMany(mappedBy = "product")
    private Set<Orders> order;   

	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(int productNumber) {
		this.productNumber = productNumber;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getWholesalePrice() {
		return wholesalePrice;
	}

	public void setWholesalePrice(int wholesalePrice) {
		this.wholesalePrice = wholesalePrice;
	}

	public Set<Orders> getOrder() {
		return order;
	}

	public void setOrder(Set<Orders> order) {
		this.order = order;
	}
	
	
}
