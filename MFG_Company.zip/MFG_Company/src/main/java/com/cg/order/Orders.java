package com.cg.order;


import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Order_Details") 
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "order_number")
	private int orderNumber;
	
	@Column(name = "customer_number", length=50)
	private int customerNumber;

	@Column(name = "order_date")
	private String orderDate;

	@Column(name = "ship_date")
	private String shipDate;
	
	@Column(name = "employee_id", length=50)
	private int employeeId;
	
	@ManyToMany(cascade = {CascadeType.ALL})  
	@JoinTable(name="order_product", joinColumns= {@JoinColumn(referencedColumnName ="order_number")},  
		     inverseJoinColumns= {@JoinColumn(referencedColumnName ="product_number")}) 
	private Set<Products> product;

	public Orders() {
	super();	
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public Set<Products> getProduct() {
		return product;
	}

	public void setProduct(Set<Products> product) {
		this.product = product;
	}

	
	
}
