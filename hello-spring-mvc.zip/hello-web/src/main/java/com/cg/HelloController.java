package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {

	@RequestMapping(method = RequestMethod.GET, value = "/sayHello")
	public String sayHello(ModelMap modelMap){
		
		modelMap.addAttribute("message","Hello, Chennai!");
		
		String view = "showMessage";
		
		return view;
	}
	
	
}
