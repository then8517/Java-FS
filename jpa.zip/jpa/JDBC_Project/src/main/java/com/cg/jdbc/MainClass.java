package com.cg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainClass  {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "root");

//		ConnectionClass conObj = new ConnectionClass();
//		conObj.gettingConnection();
		Statement stmt = con.createStatement();
		ResultSet res = null;
		//stmt.executeUpdate("INSERT INTO student (studentid,firstname,lastname) VALUES (6000, 'John', 'Smith')");
		res = stmt.executeQuery("SELECT * FROM student");
		while(res.next()){
			   System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3));
			}
		//System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3));
		
	}
	
	
}
