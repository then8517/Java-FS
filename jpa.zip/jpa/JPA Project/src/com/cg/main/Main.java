package com.cg.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.book.Book;

public class Main {

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "root");
		System.out.println("Connected");
		return con;
	}

	private static void persistBook(Book book) throws SQLException, ClassNotFoundException {
		String query = "INSERT INTO book (BOOK_ID, BOOK_NAME, BOOK_PRICE, AUTHOR_NAME, GENRE) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement ps = getConnection().prepareStatement(query);
		ps.setInt(1, book.getBookID());
		ps.setString(2, book.getBookName());
		ps.setInt(3, book.getBookPrice());
		ps.setString(4, book.getAuthorName());
		ps.setString(5, book.getGenre());

		ps.executeUpdate();
	}

	private static Book findBook(int bookID) throws SQLException, ClassNotFoundException {
		Book book = new Book(bookID);
		String query = "SELECT * FROM book WHERE BOOK_ID = ? ";
		PreparedStatement ps = getConnection().prepareStatement(query);

		ps.setInt(1, bookID);

		ResultSet res = ps.executeQuery();
		while (res.next()) {
			book.setBookName(res.getString(2));
			book.setBookPrice(res.getInt(3));
			book.setAuthorName(res.getString(4));
			book.setGenre(res.getString(5));
		}
		return book;

	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		persistBook(new Book(1001, "Java HeadFirst", 150, "Bert Bates and Kathy Sierra", "Java"));
		Book book = findBook(1001);
		System.out.println("# " + book);
	}

}
