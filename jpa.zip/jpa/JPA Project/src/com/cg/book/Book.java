package com.cg.book;

public class Book {
	private int bookID;
	private String bookName;
	private int bookPrice;
	private String authorName;
	private String genre;

	
	@Override
	public String toString() {
		return "Book [bookID=" + bookID + ", bookName=" + bookName + ", bookPrice=" + bookPrice + ", authorName="
				+ authorName + ", genre=" + genre + "]";
	}

	public Book(int bookID) {
		super();
		this.bookID = bookID;
	}

	public Book(int bookID, String bookName, int bookPrice, String authorName, String genre) {
		super();
		this.bookID = bookID;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
		this.authorName = authorName;
		this.genre = genre;
	}


	public Book() {
		// TODO Auto-generated constructor stub
	}

	public int getBookID() {
		return bookID;
	}

	public void setBookID(int bookID) {
		this.bookID = bookID;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
}
