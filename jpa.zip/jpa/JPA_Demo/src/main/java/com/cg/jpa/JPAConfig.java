package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAConfig {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		Books obj1 = new Books();
		obj1.setBookId(1001);
		obj1.setBookName("Java HeadFirst");
		obj1.setAuthorName("Bert Bates and Kathy Sierra");
		obj1.setBookPrice(690);
		obj1.setGenre("Java");
		em.getTransaction().commit();
	}

}
