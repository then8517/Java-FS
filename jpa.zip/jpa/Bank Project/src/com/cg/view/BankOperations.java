package com.cg.view;

import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.service.AccountService;

public class BankOperations {
	AccountService serviceObj = new AccountService();
	Scanner scan = new Scanner(System.in);
	
	public void createAccount() {
		System.out.println("Enter your name: ");
		String name = scan.next();
		System.out.println("Enter your mobile number: ");
		long mobNo = scan.nextLong();
		long accNo = 12345 + mobNo;
		double balance = 500.00f;
		Account createAccObj = new Account(accNo, name, mobNo, balance);
		System.out.println("Account created with Account Number "+accNo);
		serviceObj.createAccount(createAccObj);
		
	}

	public void checkBalance() {
		// TODO Auto-generated method stub
		
	}

	public void transferAmount() {
		// TODO Auto-generated method stub
		
	}

	public void withdrawAmount() {
		// TODO Auto-generated method stub
		
	}

}
