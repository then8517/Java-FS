package com.cg.junit;

import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.service.AccountService;

public class AccountTest {
	AccountService serviceTestObj = new AccountService();
	
	@Test
	void testCreateAccount() {
		String name = "Thenmozhi";
		long mobNo = 99637;
		long accNo = 12345;
		double balance = 500.00;
		Account createAccObj = new Account(accNo, name, mobNo, balance);
		serviceTestObj.createAccount(createAccObj);
	}
}
