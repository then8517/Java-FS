package com.cg.service;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;

public class AccountService {
	AccountDAO daoObj = new AccountDAO();
	public void createAccount(Account createAccObj) {
	daoObj.addCustomer(createAccObj);
	}

}
