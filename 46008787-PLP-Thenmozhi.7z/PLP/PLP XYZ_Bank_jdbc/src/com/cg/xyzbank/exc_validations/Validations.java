package com.cg.xyzbank.exc_validations;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author Thenmozhi M Date:17/1012019 Description:Implementing validation
 *         methods for phone number and name of the user
 *
 */
public class Validations extends RuntimeException {

	Scanner scan = new Scanner(System.in);

	Validations validate;

	// VALIDATING PHONE NUMBER

	public String validatePhoneNo(String phoneNo) {
		Validations validate = new Validations();
		try {
			Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}");
			Matcher matcher = pattern.matcher(phoneNo);
			if (!(matcher.matches())) {
				System.err.println("PLEASE ENTER A VALID CONTACT NUMBER");
				System.out.println("ENTER PHONE NUMBER AGAIN");
				phoneNo = scan.next();
				throw validate;
			}

		} catch (Validations phoneNumberException) {
			phoneNumberException.printStackTrace();

		}

		return phoneNo;
	}

	// VALIDATING NAME

	public String validateName(String name) {
		Validations validate = new Validations();
		try {
			if (Pattern.matches("([A-Z])*([a-z])*", name)) {
				return name;

			} else {

				System.err.println("Name should only have alphabets.");
				throw validate;
			}

		} catch (Validations nameException) {
			nameException.printStackTrace();
			System.exit(0);

		}

		return name;

	}
	
	//VALIDATING AMOUNT
	
	public double validateAmount(double bal, double amount) {
		Validations validate = new Validations();
		try {
			if (bal>amount) {
				return bal;

			} else {

				System.err.println("Name should only have alphabets.");
				
				throw validate;
			}

		} catch (Validations amountException) {
			amountException.printStackTrace();
			System.exit(0);

		}

		return bal;

	}

	
}
