package com.cg.xyzbank.pojo;
/**
 * 
 * @author Thenmozhi M
 * Date:16/10/2019
 * Description:Bean class for Banking operations
 *
 */
public class Account {
	
	
	
	private String accountHolderName;
	
	private long accountNo;
	
	private String accountType;
	
	private double currentbalance;
	
	private String phoneNo;
	
	//GETTER AND SETTER STARTS

	
	public String getAccountHolderName() {
		
		return accountHolderName.toUpperCase();
		
	}

	
	
	public void setAccountHolderName(String accountHolderName) {
		
		this.accountHolderName = accountHolderName.toUpperCase();
	}

	
	
	public long getAccountNo() {
		
		return accountNo;
		
	}

	
	
	public void setAccountNo(long accountNo2) {
		
		this.accountNo = accountNo2;
		
	}
	
	

	public String getAccountType() {
		
		return accountType.toUpperCase();
		
	}
	
	

	public void setAccountType(String accountType) {
		
		this.accountType = accountType.toUpperCase();
		
	}
	
	

	public double getCurrentbalance() {
		
		return currentbalance;
		
	}

	
	
	public void setCurrentbalance(double currentbalance2) {
		
		this.currentbalance = currentbalance2;
		
	}
	
	

	public String getPhoneNo() {
		
		return phoneNo;
		
	}

	
	
	public void setPhoneNo(String phoneNo) {
		
		this.phoneNo = phoneNo;
		
	}
	
	//GETTER AND SETTER ENDS
	
	
	
	//TO STRING

	@Override
	public String toString() {
		
		return "ACCOUNT HOLDER NAME: " + accountHolderName + "\nACCOUNT NUMBER: " + accountNo + "\nACCOUNT TYPE: "
				
				+ accountType + "\nPHONE NUMBER: " + phoneNo + "\nCURRENT BALANCE: " + currentbalance + "";
		
	}
	
	

}
