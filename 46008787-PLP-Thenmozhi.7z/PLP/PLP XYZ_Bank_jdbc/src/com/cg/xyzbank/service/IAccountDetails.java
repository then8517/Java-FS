package com.cg.xyzbank.service;

import com.cg.xyzbank.pojo.Account;

public interface IAccountDetails {
	
	public void createAccount(Account account);
	
	public void showingBalance(long accountNo);

	public void deposit(long accountNo, double amount);

	public void withdraw(long accountNo, double amount);

	public void transfer(long accountNo, long accountNo1, double amount);

	public void viewDetails(long accountNo);

	public void printTransaction(long accountNo);

}
