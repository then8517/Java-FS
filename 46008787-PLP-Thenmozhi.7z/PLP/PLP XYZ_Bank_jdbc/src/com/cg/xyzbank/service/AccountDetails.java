package com.cg.xyzbank.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.xyzbank.dao.Dao;
import com.cg.xyzbank.dao.IDao;
import com.cg.xyzbank.exc_validations.Validations;
import com.cg.xyzbank.pojo.Account;
/**
 * 
 * @author Thenmozhi M
 * Date:16/10/2019
 * Description:Collecting inputs from view class and implementing logics for banking operations
 *  and passing the data to the dao class
 *
 */
public class AccountDetails implements IAccountDetails {
	
	Account account;	
	IDao dao;	
	List<Account> accList = new ArrayList<>();	
	Scanner scan = new Scanner(System.in);	
	Validations validate=new Validations();
	
	//CREATING ACCOUNT

	public void createAccount(Account account) {      
		dao = new Dao();
		int status = dao.createAccount(account);                                 //PASSING THE DATA LIST TO THE DAO CLASS
		
		if (status != 0) {		
			System.out.println("NEW ACCOUNT CREATED");			
		} else {			
			System.err.println("CHECK AGAIN");
		}

		System.out.println("Kindly note down your Account Number");		
		System.out.println("YOUR ACCOUNT NUMBER: " + account.getAccountNo());

	}

	
	//BALANCE CHECK
	
	public void showingBalance(long accountNo) {         

		dao = new Dao();	
		System.out.println("YOUR AVAILABLE BALANCE IS: " + dao.showingBalance(accountNo));    //PASSING THE DATA TO THE DAO CLASS TO CHECK BALANCE
	}

	
	 //DEPOSIT
	
	public void deposit(long accountNo, double amount) {  

		dao = new Dao();
		double bal = dao.showingBalance(accountNo);
		bal = bal + amount;		
		long l = dao.deposit(accountNo, bal);                                //PASSING THE DATA TO THE DAO CLASS TO DEPOSIT AMOUNT   
		
		if (l != 0) {			
			System.out.println("DEPOSIT SUCCESSFUL");			
		} else {			
			System.err.println("FAILED");			
		}
		
		System.out.println("YOUR CURRENT BALANCE IS: " + dao.showingBalance(accountNo));		
		String depositMessage = "Rs. " + amount + " is deposited to the Account Number: " + accountNo;                   		
		dao.insertTransaction(accountNo, depositMessage);
		
	}

	
	  //WITHDRAW
	
	public void withdraw(long accountNo, double amount) {        
		

		dao = new Dao();
		double bal = dao.showingBalance(accountNo);		
		bal = bal - amount;
		long l = dao.deposit(accountNo, bal);                                //PASSING THE DATA TO THE DAO CLASS TO WITHDRAW AMOUNT		
		
		if (l != 0) {			
			System.out.println("WITHDRAWN SUCCESSFUL");
		} else {			
			System.err.println("FAILED");
		}
		
		System.out.println("YOUR CURRENT BALANCE IS: " + dao.showingBalance(accountNo));		
		String withdrawMessage = "Rs. " + amount + " is withdrawn from the Account Number: " + accountNo;		
		dao.insertTransaction(accountNo, withdrawMessage);
		
	}

	
	//TRANSFERING FUNDS
	
	public void transfer(long accountNo, long accountNo1, double amount) {         

		dao = new Dao();
		
		double bal = dao.showingBalance(accountNo);	
		
		bal=validate.validateAmount(bal, amount);
		
		bal = bal - amount;		
		dao.deposit(accountNo, bal);
		double bal1 = dao.showingBalance(accountNo1);		
		bal1 = bal1 + amount;		
		long l = dao.deposit(accountNo1, bal1);
		
		if (l != 0) {
			
			System.out.println("TRANSACTION SUCCESSFUL");
			
		} else {
			System.err.println("FAILED!!!");
			
		}
		
		System.out.println("YOUR CURRENT BALANCE IS: " + dao.showingBalance(accountNo));		
		String transferMessage = "Rs. " + amount + " is transferred from Account Number: " + accountNo + " to Account Number: " + accountNo1;		
		dao.insertTransaction(accountNo1, transferMessage);
		dao.insertTransaction(accountNo, transferMessage);
		
	}

	
	//VIEWING DETAILS
	
	public void viewDetails(long accountNo) {
		

		dao = new Dao();
		List<Account> accList = new ArrayList<Account>();		
		accList = dao.viewDetails(accountNo);                        //PASSING THE DATA TO THE DAO CLASS TO VIEW CUSTOMER DETAILS
		System.out.println(accList);

	}

	
	//PRINTING TRANSACTIONS
	
	public void printTransaction(long accountNo) {
		
		dao = new Dao();
		dao.printTransaction(accountNo);                              //PASSING THE DATA TO THE DAO CLASS TO PRINT TRANSACTION DETAILS
		
	}

}
