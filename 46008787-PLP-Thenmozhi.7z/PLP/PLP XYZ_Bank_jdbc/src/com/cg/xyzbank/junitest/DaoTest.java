package com.cg.xyzbank.junitest;

import java.util.Random;
import org.junit.jupiter.api.Test;
import com.cg.xyzbank.dao.Dao;
import com.cg.xyzbank.pojo.Account;

class DaoTest {
	
	@Test
	void testCreateAccount() {                                                    //TESTING ACCOUNT CREATION METHOD
		
		Account account = new Account();
		
        Random rand = new Random();
		        
		int accountNo = rand.nextInt(1000);		
		account.setAccountHolderName("Kavi");
		account.setAccountNo(accountNo);		
		account.setAccountType("Savings");		
		account.setCurrentbalance(500.0);		
		account.setPhoneNo("9638527410");
		
		Dao obj = new Dao();
		
		obj.createAccount(account);
	}
	
	
	@Test
	public void testShowingBalance() {                                            //TESTING BALANCE CHECK METHOD
		
		int accountNo=975;
		
		Dao obj = new Dao();
		
		obj.showingBalance(accountNo);
		
		
	}

}
