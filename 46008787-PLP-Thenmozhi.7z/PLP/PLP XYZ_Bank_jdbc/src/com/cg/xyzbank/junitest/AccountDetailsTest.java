package com.cg.xyzbank.junitest;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import com.cg.xyzbank.dao.Dao;
import com.cg.xyzbank.dao.IDao;
import com.cg.xyzbank.pojo.Account;

class AccountDetailsTest {
	
	List<Account> accList = new ArrayList<>();

	@Test
	void testCreateAccount() {                                               //TESTING ACCOUNT CREATION METHOD

		Account account = new Account();
		
		account.setAccountHolderName("Then");	
		account.setAccountNo(123);		
		account.setAccountType("Savings");		
		account.setCurrentbalance(500.0);		
		account.setPhoneNo("9638527410");

		
		accList.add(account);
		
		IDao dao = new Dao();
		
		dao.createAccount(account);

	}

	@Test
	void testDeposit() {                                                    //TESTING DEPOSIT METHOD
		
		int accountNo = 975;		
		double amount = 500.0;		
		
		IDao dao = new Dao();	
		
		double bal = dao.showingBalance(accountNo);
		
		bal = bal + amount;
				
		dao.deposit(accountNo, bal);

	}

	@Test
	void testWithdraw() {                                                   //TESTING WITHDRAW METHOD
		
		int accountNo = 975;	
		double amount = 100.0;		

		IDao dao = new Dao();
		
		double bal = dao.showingBalance(accountNo);		
		
		bal = bal - amount;
		
		dao.deposit(accountNo, bal);

	}

	@Test
	void testTransfer() {                                                    //TESTING TRANSFER METHOD
		
		int accountNo = 975;		
		int accountNo1 = 213;		
		double amount = 100.0;
		
		IDao dao = new Dao();
		
		double bal = dao.showingBalance(accountNo);
				
		bal = bal - amount;

		dao.deposit(accountNo, bal);
		
		double bal1 = dao.showingBalance(accountNo1);
		
		bal1 = bal1 + amount;
				
		dao.deposit(accountNo1, bal1);

	}

}
