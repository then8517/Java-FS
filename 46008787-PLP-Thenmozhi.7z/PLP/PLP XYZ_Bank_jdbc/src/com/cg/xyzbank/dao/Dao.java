package com.cg.xyzbank.dao;

import com.cg.xyzbank.helper.DbConnection;
import com.cg.xyzbank.pojo.Account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author Thenmozhi M
 * Date:17/10/2019
 * Description:Creating the query statement and executing in the database.
 *
 */
public class Dao implements IDao {
	
	private Connection con;
	
	private PreparedStatement ps;
	
	private ResultSet rs;
	
	Account account;
	
	double bal;
	
	int updatedbal;

	
	//CREATING ACCOUNT
	
	@Override
	public int createAccount(Account account) {
		
		try {
			con = DbConnection.getConnection();
			ps = con.prepareStatement("insert into ShowBalance values(?,?,?,?,?)");
			ps.setString(1, account.getAccountHolderName());			
			ps.setLong(2, account.getAccountNo());			
			ps.setString(3, account.getAccountType());			
			ps.setDouble(4, account.getCurrentbalance());			
			ps.setString(5, account.getPhoneNo());			
			ps.executeUpdate();

		} catch (Exception e) {
			
			e.printStackTrace();
		}

		return 1;
	}


	
	//BALANCE CHECK
	
	@Override
	public double showingBalance(long accountNo) {
		
		con = DbConnection.getConnection();
		
		try {			
			ps = con.prepareStatement("select BALANCE from ShowBalance where ACCOUNTNUMBER=" + accountNo);			
			rs = ps.executeQuery();			
			
			while (rs.next()) {				
				bal = rs.getDouble("BALANCE");				
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return bal;
	}

	
	
	 //DEPOSIT
	
	@Override
	public long deposit(long accountNo, double bal) {
		
		long l = 0;
		
		try {			
			l = ps.executeUpdate("update ShowBalance set BALANCE=" + bal + "where ACCOUNTNUMBER=" + accountNo);
			
			while (rs.next()) {			
				updatedbal = rs.getInt("BALANCE");
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return l;

	}
	


	//VIEWING DETAILS
	
	@Override
	public List<Account> viewDetails(long accountNo) {
		
		ArrayList<Account> arrayList = new ArrayList<>();

		try {
			con = DbConnection.getConnection();			
			ps = con.prepareStatement("select * from ShowBalance where ACCOUNTNUMBER=" + accountNo);			
			rs = ps.executeQuery();
			
			while (rs.next()) {
				
				Account a = new Account();				
				a.setAccountHolderName(rs.getString(1));				
				a.setAccountNo(rs.getInt(2));				
				a.setAccountType(rs.getString(3));				
				a.setCurrentbalance(rs.getDouble(4));				
				a.setPhoneNo(rs.getString(5));

				arrayList.add(a);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return arrayList;

	}

	
	//INSERTING TRANSACTIONS INTO DATABASE
	@Override
	public void insertTransaction(long accountNo, String message) {
		
		try {
			
			con = DbConnection.getConnection();			
			ps = con.prepareStatement("insert into TransactionQuery values(?,?)");
			ps.setLong(1, accountNo);			
			ps.setString(2, message);			
			ps.executeUpdate();

		} catch (Exception e) {
			
			e.printStackTrace();

		}

	}

	//PRINTING TRANSACTIONS
	
	@Override
	public void printTransaction(long accountNo) {
		
		String message = null;
		
		try {
			
			con = DbConnection.getConnection();
			ps = con.prepareStatement("select MESSAGE from TransactionQuery where ACCOUNTNUMBER=" + accountNo);			
			rs = ps.executeQuery();
			
			while (rs.next()) {
				
				message = rs.getString(1);				
				System.out.println(message);
			}

		} catch (Exception e) {

		}

	}

}
