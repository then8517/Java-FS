package com.cg.xyzbank.dao;

import java.util.List;

import com.cg.xyzbank.pojo.Account;

public interface IDao {

	public int createAccount(Account account);

	public long deposit(long accountNo, double bal);

	public double showingBalance(long accountNo);

	public List<Account> viewDetails(long accountNo);

	public void insertTransaction(long accountNo, String message);

	public void printTransaction(long accountNo);

	

}
