package com.cg.xyzbank.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * 
 * @author Thenmozhi M
 * Date:16/10/2019
 * Description:Registering into Driver class and getting connected to the database.
 *
 */
public class DbConnection {
	
	static Connection conn = null;

	
	public static Connection getConnection() {
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return conn;
	}

}
