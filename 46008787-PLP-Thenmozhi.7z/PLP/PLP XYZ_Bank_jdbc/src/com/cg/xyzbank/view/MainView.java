
package com.cg.xyzbank.view;

import java.util.Scanner;

/**
 * 
 * @author Thenmozhi M 
 * Date:16/10/2019 
 * Description:Declaring Banking Operation methods and user view
 *
 */
public class MainView {

	public static void main(String[] args) {

		char i;
		int option;

		Scanner scan = new Scanner(System.in);

		do {

			BankOperations obj = new BankOperations();

			System.out.println("***Welcome to XYZ Bank*** ");
			System.out.println("Select option to you wish to continue");
			System.out.println(
					"\n1. CREATE ACCOUNT\n2. SHOW BALANCE\n3. DEPOSIT\n4. WITHDRAW\n5. MONEY TRANSFER\n6. VIEW DETAILS\n7. PRINT TRANSACTIONS");
			option = scan.nextInt();


				switch (option) {

				case 1:					
					obj.accountCreation();					
					break;

				case 2:					
					obj.balanceCheck();					
					break;

				case 3:				
					obj.deposit();					
					break;

				case 4:
					obj.withdraw();					
					break;

				case 5:					
					obj.fundTransfer();					
					break;

				case 6:					
					obj.viewDetails();					
					break;
					
				case 7:					
					obj.transactionDetails();					
					break;

				default:					
					System.out.println("INVALID OPTION");					
					break;

				}
				
				System.out.println("DO YOU WISH TO CONTINUE? ");				
				System.out.print("PRESS'y' TO CONTINUE (or)  PRESS 'n' TO EXIT ");
				
				i = scan.next().charAt(0);
				
				if (i == 'y' || i == 'Y')					
					continue;				
				else {				
					System.out.println("Thank You ! Use our services next time....");					
					System.exit(0);
				}			
		} while (option != 8);
		scan.close();
	}

}
