package com.cg.xyzbank.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.xyzbank.dao.Dao;
import com.cg.xyzbank.dao.IDao;
import com.cg.xyzbank.exc_validations.Validations;
import com.cg.xyzbank.pojo.Account;
import com.cg.xyzbank.service.AccountDetails;
/**
 * 
 * @author Thenmozhi M
 * Date:16/10/2019
 * Description:Implementing Bank Operation methods and collecting inputs from user
 *
 */


public class BankOperations {
	
	Account account;	
	IDao dao;	
	List<Account> accList = new ArrayList<>();	
	Scanner scan = new Scanner(System.in);	
	AccountDetails serviceObj = new AccountDetails();
	Scanner sc = new Scanner(System.in);	
	Validations validate=new Validations();

	
	//COLLECTING DATA FOR ACCOUNT CREATION
	
	public void accountCreation() {
				
		System.out.println("Enter Customer Name:");		
		String accountHolderName = validate.validateName(scan.next());        		
		Random rand = new Random();	
		int max=999999;
		int min=100000;
		long accountNo = rand.ints(min, (max + 1)).limit(1).findFirst().getAsInt();	
		System.out.println("Enter the account type to continue:");		
		String accountType = scan.next();
		System.out.println("Enter customer phone number: ");		
		String phoneNo = validate.validatePhoneNo(scan.next());		
		double currentbalance = 500.00;
		account = new Account();		
		account.setAccountHolderName(accountHolderName);		
		account.setAccountNo(accountNo);		
		account.setAccountType(accountType);		
		account.setCurrentbalance(currentbalance);		
		account.setPhoneNo(phoneNo);
		dao = new Dao();		
		accList.add(account);                                                     //PASSING THE DATA LIST TO THE SERVICE CLASS		
		serviceObj.createAccount(account);	

	}

	
	//COLLECTING DATA TO CHECK BALANCE
	
	public void balanceCheck() {
				
		System.out.println("Enter Account Number:");		
		long accountNo = scan.nextLong();
		serviceObj.showingBalance(accountNo);                           //PASSING THE DATA TO THE SERVICE CLASS TO CHECK BALANCE        

	}

	
	//COLLECTING DATA TO DEPOSIT
	
	public void deposit() {
				
		System.out.println("Enter Account Number:");	
		long accountNo = scan.nextLong();
		System.out.println("Enter amount to be deposited: ");		
		double amount = scan.nextDouble();
		serviceObj.deposit(accountNo, amount);                            //PASSING THE DATA TO THE SERVICE CLASS TO DEPOSIT AMOUNT   
	}
	
	
	//COLLECTING DATA TO WITHDRAW
	
	public void withdraw() {
				
		System.out.println("Enter Account Number:");		
		long accountNo = scan.nextInt();
		System.out.println("Enter amount to be withdrawn: ");		
		double amount = scan.nextDouble();
		serviceObj.withdraw(accountNo, amount);                            //PASSING THE DATA TO THE SERVICE CLASS TO WITHDRAW AMOUNT
	}

	
	//COLLECTING DATA TO TRANSFER FUNDS
	
	public void fundTransfer() {
			
		System.out.println("Enter Account Number:");		
		long accountNo = scan.nextInt();		
		System.out.println("Enter account number to be transferred:");		
		long accountNo1 = scan.nextInt();		
		System.out.println("Enter amount to be transferrred: ");		
		double amount = scan.nextDouble();		
		serviceObj.transfer(accountNo,accountNo1,amount);                  //PASSING THE DATA TO THE SERVICE CLASS TO TRANSFER AMOUNT
				
	}
	
	
	//COLLECTING DATA TO VIEW CUSTOMER DETAILS
	
	public void viewDetails() {
				
		System.out.println("Enter Account Number:");		
		long accountNo = scan.nextInt();
		serviceObj.viewDetails(accountNo);                                 //PASSING THE DATA TO THE SERVICE CLASS TO VIEW CUSTOMER DETAILS
		
	}
	
	
	//COLLECTING DATA TO PRINT TRANSACTION DETAILS
	
	public void transactionDetails() {
		
		System.out.println("Enter Account Number:");		
		long accountNo = scan.nextInt();
		serviceObj.printTransaction(accountNo);                          //PASSING THE DATA TO THE SERVICE CLASS TO PRINT TRANSACTION DETAILS
	
	}

}
