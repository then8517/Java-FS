package com.cg.xyz.service;

import com.cg.xyz.bean.Account;
import com.cg.xyz.dao.Dao;
import com.cg.xyz.dao.IDao;
/**
 * 
 * @author Thenmozhi M
 * Date:17/10/2019
 * Description:Collecting inputs from view class and implementing logics for banking operations 
 * and passing the data to the dao class
 *
 */
public class AccountService implements IAccountService {

	IDao dao = new Dao();

	//CREATING ACCOUNT

	public void bankAccountCreateService(Account bankBeanObjCreateAccountObj) {
		dao.addCustomer(bankBeanObjCreateAccountObj);
	}

	//BALANCE CHECK
	
	public void BalanceService(Account bankBeanShowBalObj) {
		if (dao.hm().isEmpty()) {
			System.out.println("Please create an account first.");
		} else {
			if (dao.hm().containsKey(bankBeanShowBalObj.getAccNo())) {
				System.out.println(
						"Your Account Balance is: " + dao.hm().get(bankBeanShowBalObj.getAccNo()).getBalance());
			} else {
				System.err.println("No such Account Exist.");
			}
		}
	}

	//DEPOSIT
	
	public void depositService(Account bankBeanDepObj) {

		if (dao.hm().isEmpty()) {
			System.out.println("Please create an account first.");
		} else {

			if (dao.hm().containsKey(bankBeanDepObj.getAccNo())) {
				float dep = bankBeanDepObj.getDepAmount() + dao.hm().get(bankBeanDepObj.getAccNo()).getBalance();
				dao.hm().get(bankBeanDepObj.getAccNo()).setBalance(dep);
				System.out.println("Deposited successfully.");
				System.out.println("Your account balance is: " + dao.hm().get(bankBeanDepObj.getAccNo()).getBalance());
			}

			else {

				System.err.println("No such Account Exist.");
			}
		}
	}

	
	 //WITHDRAW
	
	public void withdrawService(Account bankBeanWithdrawObj) {
		if (dao.hm().isEmpty()) {
			System.out.println("Please create an account first.");

		} else

		{
			if (bankBeanWithdrawObj.getWithdrawAmount() > dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance()) {
				System.out.println("Can't withdraw money. Account Balance is low.");
			} else {
				if (dao.hm().containsKey(bankBeanWithdrawObj.getAccNo())) {
					float dep = dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance()
							- bankBeanWithdrawObj.getWithdrawAmount();
					dao.hm().get(bankBeanWithdrawObj.getAccNo()).setBalance(dep);
					System.out.println("Withdraw successful.");
					System.out.println(
							"Your account balance is: " + dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance());
				} else {
					System.err.println("No such Account Exist.");

				}

			}

		}

	}

	
	//TRANSFERING FUNDS
	
	public void transferService(Account bankBeanFundTransObj) {

		if (dao.hm().isEmpty()) {

			System.out.println("Please create an account first.");

		}

		else {

			if (dao.hm().containsKey(bankBeanFundTransObj.getSourceAccNo())) {

				if (dao.hm().containsKey(bankBeanFundTransObj.getDestAccNo())) {
					if (dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() > bankBeanFundTransObj
							.getTransferAmount()) {
						float transfer = bankBeanFundTransObj.getTransferAmount();
						dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).setBalance(
								dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() - transfer);
						dao.hm().get(bankBeanFundTransObj.getDestAccNo())
								.setBalance(dao.hm().get(bankBeanFundTransObj.getDestAccNo()).getBalance() + transfer);
						System.out.println("Funds Transferred Successfully.");
						System.out
								.println("Remaining balance in account number " + bankBeanFundTransObj.getSourceAccNo()
										+ " is: " + dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance());

					} else {
						System.err.println("Can't transfer money. Source Account Balance is low.");
					}
				} else {
					System.err.println("Destination Account Not Exist.");
				}
			}

			else {
				System.err.println("Source Account Not Exist.");

			}

		}

	}

}