package com.cg.xyz.service;

import com.cg.xyz.bean.Account;

public interface IAccountService {
	
	public void bankAccountCreateService(Account bankBeanObjCreateAccountObj);

	public void BalanceService(Account bankBeanShowBalObj);

	public void depositService(Account bankBeanDepObj);

	public void withdrawService(Account bankBeanWithdrawObj);

	public void transferService(Account bankBeanFundTransObj);

}
