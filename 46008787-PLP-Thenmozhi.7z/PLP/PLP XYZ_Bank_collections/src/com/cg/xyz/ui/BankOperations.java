package com.cg.xyz.ui;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.xyz.bean.Account;
import com.cg.xyz.service.AccountService;
/**
 * 
 * @author Thenmozhi M
 * Date:17/10/2019
 * Description:Implementing Bank Operation methods and collecting inputs from user
 *
 */

public class BankOperations {
	
	AccountService bankServiceObj = new AccountService();	
	Scanner sc = new Scanner(System.in);
	
	
	//COLLECTING DATA FOR ACCOUNT CREATION
	
	public void accountCreation() {
		
		System.out.print("Enter Name: ");		
		String name = nameCheck(sc.next());		
		System.out.print("Enter Mobile No.: ");		
		long mobno = mobileNumberCheck(sc.nextLong());		
		long accno = 52345676 + mobno ;		
		System.out.print("Enter Balance: ");		
		float balance = amountCheck(sc.nextFloat());		
		Account CreateAccountObj = new Account(accno, name, mobno, balance);        		
		System.out.println("Account created with Account Number: " +accno);		
		bankServiceObj.bankAccountCreateService(CreateAccountObj);               //PASSING THE DATA LIST TO THE SERVICE CLASS

	} 
	

	//COLLECTING DATA TO CHECK BALANCE
	
	public void balanceCheck() {
		
		System.out.print("Enter Account Number: ");		
		long accno = sc.nextLong();		
		Account ShowBalObj = new Account(accno);
		bankServiceObj.BalanceService(ShowBalObj);                               //PASSING THE DATA TO THE SERVICE CLASS TO CHECK BALANCE

	}
	
	//COLLECTING DATA TO DEPOSIT

	public void deposit() {
		
		System.out.print("Enter Account Number: ");
		long accno = sc.nextLong();
		System.out.print("Enter Deposit Amount: ");
		float depAmount = amountCheck(sc.nextFloat());
		Account DepositObj = new Account(accno, depAmount);
		bankServiceObj.depositService(DepositObj);                             //PASSING THE DATA TO THE SERVICE CLASS TO DEPOSIT AMOUNT   
	
	}
	
	
	//COLLECTING DATA TO WITHDRAW

	public void withdraw() {
		System.out.print("Enter Account Number: ");
		long accno = sc.nextLong();
		System.out.print("Enter Withdraw Amount: ");
		float withdrawAmount = amountCheck(sc.nextFloat());
		Account WithdrawObj = new Account(withdrawAmount, accno);
		bankServiceObj.withdrawService(WithdrawObj);                         //PASSING THE DATA TO THE SERVICE CLASS TO WITHDRAW AMOUNT
	}
	
	
	//COLLECTING DATA TO TRANSFER FUNDS

	public void fundTransfer() {
		System.out.println("Enter Source Account Number: ");
		long sourceAccNo = sc.nextLong();
		System.out.println("Enter Destination Account Number: ");
		long destinationAccNo = sc.nextLong();
		System.out.println("Enter Amount to transfer: ");
		float transferAmount = amountCheck(sc.nextFloat());
		Account FundTransferObj = new Account(sourceAccNo, destinationAccNo, transferAmount);
		bankServiceObj.transferService(FundTransferObj);                    //PASSING THE DATA TO THE SERVICE CLASS TO TRANSFER AMOUNT
		String transactions = transferAmount + " transferred from Account number " + sourceAccNo + " to " + destinationAccNo;
		FundTransferObj = new Account(transactions);                           
	}

	
	//COLLECTING DATA TO PRINT TRANSACTION DETAILS
	
	public void printTransactions() {
		System.out.println(Arrays.toString(Account.transactions));
	}

	
	//AMOUNT CHECK VALIDATIONS
	
	public float amountCheck(float amount) {
		while (true) {
			if (amount <= 0) {
				System.err.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			} else {
				return amount;
			}
		}
	}

	//NAME CHECK VALIDATIONS
	
	public String nameCheck(String name) {
		while (true) {
			if (Pattern.matches("([A-Z])*([a-z])*", name)) {
				return name;
			} else {
				System.err.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}

	//PNONE NUMBER CHECK VALIDATIONS
	
	public long mobileNumberCheck(long mob) {
		while (true) {
			if (String.valueOf(mob).length() < 10) {
				System.err.println("Enter valid mobile number.");
				System.out.println("Enter again: ");
				mob = sc.nextLong();
			} else {
				return mob;
			}
		}
	}
}