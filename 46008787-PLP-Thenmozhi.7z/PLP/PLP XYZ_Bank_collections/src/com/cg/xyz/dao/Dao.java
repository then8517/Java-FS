package com.cg.xyz.dao;
import java.util.HashMap;
import com.cg.xyz.bean.Account;
/**
 * 
 * @author Thenmozhi M
 * Date:17/10/2019
 * Description:Creating the database using hash map.
 *
 */
public class Dao implements IDao 
{
   Account beankBeanObj;
   HashMap<Long, Account> hashMap = new HashMap<Long, Account>();
   public int addCustomer(Account beankBeanObj) 
   {			 
	   this.beankBeanObj = beankBeanObj;						
	   hashMap.put(beankBeanObj.getAccNo(), beankBeanObj);
	return 1;			

	}
   public HashMap<Long, Account> hm()
   {				
	   return hashMap;
   }
}
