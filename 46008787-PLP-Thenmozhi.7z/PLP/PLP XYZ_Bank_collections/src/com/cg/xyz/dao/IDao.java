package com.cg.xyz.dao;

import java.util.HashMap;

import com.cg.xyz.bean.Account;

public interface IDao {
	public int addCustomer(Account beankBeanObj);

	public HashMap<Long, Account> hm();

}
