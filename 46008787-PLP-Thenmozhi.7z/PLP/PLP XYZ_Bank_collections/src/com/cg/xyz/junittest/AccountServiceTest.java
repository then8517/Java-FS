package com.cg.xyz.junittest;


import org.junit.jupiter.api.Test;

import com.cg.xyz.bean.Account;
import com.cg.xyz.service.AccountService;

class AccountServiceTest {
	AccountService bankServiceObj = new AccountService();

	@Test
	void testBankAccountCreateService() {

		String name = "Then";
		long mobno = 963541;
		long accno = 14253;
		float balance = 500.0f;
		Account createAccountObj = new Account(accno, name, mobno, balance);
		bankServiceObj.bankAccountCreateService(createAccountObj);
	}
	
	@Test
	void testBalanceService() {
		long accno=36595;
		Account balanceObj = new Account(accno);
		
		AccountService bankServiceObj = new AccountService();
		
		bankServiceObj.BalanceService(balanceObj);

	}
	
	@Test
	void testDepositService() {
		long accno=36595;
		float depAmount =500.0f;
		Account depositAccountObj = new Account(accno,depAmount);
		
		AccountService bankServiceObj = new AccountService();
		
		bankServiceObj.BalanceService(depositAccountObj);

	}
	
	@Test
	void testwithdrawService() {
		long accno=36595;
		float withdrawAmount =500.0f;
		Account withdrawObj = new Account(accno,withdrawAmount);
		
		AccountService bankServiceObj = new AccountService();
		
		bankServiceObj.BalanceService(withdrawObj);

	}
	@Test
	 void fundTransferService() {
		long sourceAccNo=1254;
		long destinationAccNo =2514;
		float transferAmount=300.0f;
		Account FundTransferObj = new Account(sourceAccNo, destinationAccNo, transferAmount);
		
		AccountService bankServiceObj = new AccountService();
		
		bankServiceObj.transferService(FundTransferObj);
		
	}

}
