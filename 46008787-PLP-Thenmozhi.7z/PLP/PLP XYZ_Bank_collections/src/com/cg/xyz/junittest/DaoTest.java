package com.cg.xyz.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cg.xyz.bean.Account;
import com.cg.xyz.dao.Dao;

class DaoTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void testCreate() {
		int accno=9354;
		String name="Then";
		long mobno=9638520;
		float balance=100.0f;
		
		
		
		Account CreateAccountObj = new Account(accno, name, mobno, balance);
		Dao obj=new Dao();
		
		assertEquals(1,obj.addCustomer(CreateAccountObj));
		
	}
	

}
