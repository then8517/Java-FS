package com.cg.bankapprest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bankapprest.exception.BankException;
import com.cg.bankapprest.model.XyzBankRest;
import com.cg.bankapprest.model.XyzBankTransactionRest;
import com.cg.bankapprest.service.IXyzBankService;



@RestController
@RequestMapping("api/v1")
public class XyzBankController {
	
	@Autowired
	IXyzBankService bankService;
	
	@RequestMapping(value="/user/add" ,method=RequestMethod.POST)
	public XyzBankRest addBankAccount(@RequestBody XyzBankRest bank) throws BankException
	{
		
		return bankService.addBankAccount(bank);
	}

	@RequestMapping("/user/show/{accountId}")
	public String showBalance(@PathVariable int accountId) throws BankException
	{
		return "Your current balance is: Rs."+bankService.showBalance(accountId);
	}

	@RequestMapping(value="/user/deposit/{accountId}/{deposit}",method=RequestMethod.PUT)
	public String depositAmount(@PathVariable Long accountId,@PathVariable Long deposit) throws BankException{
		try {
			 bankService.depositAmount(accountId, deposit);
			return "Transaction successful!!";
	}
		catch(Exception ex)
		{
			return "Oops!!Transaction Failed!";
		} 
		
	}

	@RequestMapping(value="/user/withdraw/{accountId}/{withdraw}",method=RequestMethod.PUT)
	public  String withdrawAmount(@PathVariable Long accountId,@PathVariable Long withdraw) throws BankException
	{
		try {
			bankService.withdrawAmount(accountId, withdraw);
			return "Transaction successful!!";
	}
		catch(Exception ex)
		{
			return "Oops!!Transaction Failed!";
		}
	}
	@RequestMapping(value="/user/transfer/{source}/{destination}/{money}",method=RequestMethod.GET)
	public  String cashTransfer(@PathVariable long source,@PathVariable long destination,@PathVariable double money) throws BankException
	{
		try {
			bankService.cashTransfer(source, destination, money);
			return "Transaction successful!!";
		}
		catch(Exception ex)
		{
			return "Oops!!Transaction Failed!Please check again!";
		}
		
	}
	@RequestMapping(value="/customer/printTransaction/{accno}",method=RequestMethod.GET)
    public XyzBankTransactionRest printTransaction(@PathVariable long accno){
        return bankService.printTransaction(accno);
    }

	}
