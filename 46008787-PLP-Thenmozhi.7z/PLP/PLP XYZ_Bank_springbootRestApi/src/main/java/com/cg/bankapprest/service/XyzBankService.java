package com.cg.bankapprest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapprest.dao.IXyzBank;
import com.cg.bankapprest.dao.IXyzBankTransaction;
import com.cg.bankapprest.exception.BankException;
import com.cg.bankapprest.model.XyzBankRest;
import com.cg.bankapprest.model.XyzBankTransactionRest;

@Service
public class XyzBankService implements IXyzBankService{
	
	@Autowired
	IXyzBank daoObj;

	@Autowired
	IXyzBankTransaction transactionObj;
	public XyzBankRest getDetailsById(Long accountId) throws BankException {
		try {
			return daoObj.findById(accountId).get();
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}
	}

	public XyzBankRest addBankAccount(XyzBankRest bank) throws BankException {
		try {
			return daoObj.save(bank);
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}

	}

	public double showBalance(long accountId) throws BankException {
		try {
			XyzBankRest bank = daoObj.findById(accountId).get();
			return bank.getBalance();
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}
	}
	public double depositAmount(Long accountId, double amount) throws BankException {
	    try {
	        Optional<XyzBankRest> optional=daoObj.findById(accountId);
	        XyzBankTransactionRest transaction = new XyzBankTransactionRest();
	        XyzBankRest dp=optional.get();
	        dp.setBalance(optional.get().getBalance()+amount);
	        transaction.setTransactionType("Deposit");
			transaction.setAccountNumber(accountId);
			transaction.setAmount(amount);
			transactionObj.save(transaction);
			daoObj.save(dp);
	        return daoObj.findById(accountId).get().getBalance();
	    }
	    catch(Exception e) {
	        throw new BankException(e.getMessage());
	    }
	   
	}
	
	public double withdrawAmount(long accountId,double withdraw) throws BankException {
		try {
		Optional<XyzBankRest> optional=daoObj.findById(accountId);
		XyzBankTransactionRest transaction = new XyzBankTransactionRest();
    	if(optional.isPresent())
    	{
    		XyzBankRest wd=optional.get();
        wd.setBalance(optional.get().getBalance()-withdraw);
        transaction.setAccountNumber(accountId);
        transaction.setAmount(withdraw);
        transaction.setTransactionType("Withdraw");
        transactionObj.save(transaction);
		daoObj.save(wd);
        return daoObj.findById(accountId).get().getBalance();
        }
        else
        {
            throw new BankException("Customer with accountnumber " + accountId + " does not exit");
        }
        
    }catch(Exception e) {
        throw new BankException(e.getMessage());
    }
	}

	public XyzBankRest cashTransfer(long source, long destination, double money) throws BankException 
	{
		try{
	        Optional<XyzBankRest> optional1=daoObj.findById(source);
	        Optional<XyzBankRest> optional2=daoObj.findById(destination);
	        XyzBankTransactionRest transaction = new XyzBankTransactionRest();
	        XyzBankTransactionRest transaction1 = new XyzBankTransactionRest();
	        if(optional1.isPresent() && optional2.isPresent()) {
	        	XyzBankRest deposit=optional1.get();
	        	XyzBankRest credit=optional2.get();
	            deposit.setBalance(deposit.getBalance()-money);
	            credit.setBalance(credit.getBalance()+money);
	            daoObj.save(deposit);
	            daoObj.save(credit);
	            transaction.setAccountNumber(source);
	    		transaction.setAmount(money);
	    		transaction.setTransactionType("Transfer");
	    		transactionObj.save(transaction);
	    		transaction1.setAccountNumber(destination);
	    		transaction1.setTransactionType("transfer");
	    		transaction1.setAmount(money);
	    		transactionObj.save(transaction1);
	            return daoObj.findById(source).get();
	        }
	        else
	        {
	            throw new BankException("Customer with accountnumber " + source + " does not exit");
	        }
	    }catch(Exception e) {
	        throw new BankException(e.getMessage());
	    }
	}

	public XyzBankTransactionRest printTransaction(long accno) {

		XyzBankTransactionRest transaction=transactionObj.findById(accno).get();
	            return  transaction;
	       }
	}



