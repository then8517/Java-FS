package com.cg.bankapprest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class XyzBankRest {
		@Id
		@GeneratedValue
		private long accountId;

		private String name;
		private double balance;

		private String phoneNumber;
		private String password;
		
		//GETTERS AND SETTERS
		public long getAccountId() {
			return accountId;
		}
		public void setAccountId(long accountId) {
			this.accountId = accountId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		@Override
		public String toString() {
			return "XyzBankRest [accountId=" + accountId + ", name=" + name + ", balance=" + balance + ", phoneNumber="
					+ phoneNumber + ", password=" + password + "]";
		}		
		
	}

