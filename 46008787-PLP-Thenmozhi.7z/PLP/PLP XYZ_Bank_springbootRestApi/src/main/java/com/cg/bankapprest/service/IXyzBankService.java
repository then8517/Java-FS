package com.cg.bankapprest.service;

import java.util.List;


import com.cg.bankapprest.exception.BankException;
import com.cg.bankapprest.model.XyzBankRest;
import com.cg.bankapprest.model.XyzBankTransactionRest;


public interface IXyzBankService {
	public XyzBankRest getDetailsById(Long accountId) throws BankException;

	public XyzBankRest addBankAccount(XyzBankRest bank) throws BankException;

	public double showBalance(long accountId) throws BankException;

	public double depositAmount(Long accountId, double amount) throws BankException;

	public double withdrawAmount(long accountId, double withdraw) throws BankException;

	public XyzBankRest cashTransfer(long source, long destination, double money) throws BankException;

	public XyzBankTransactionRest printTransaction(long accno);


}