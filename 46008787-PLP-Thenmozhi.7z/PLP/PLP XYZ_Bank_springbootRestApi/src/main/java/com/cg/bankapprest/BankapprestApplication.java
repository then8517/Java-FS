package com.cg.bankapprest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankapprestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankapprestApplication.class, args);
	}

}
