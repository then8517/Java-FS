package com.cg.bankapprest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bankapprest.model.XyzBankRest;
@Repository
public interface IXyzBank extends JpaRepository<XyzBankRest, Long> {

}
