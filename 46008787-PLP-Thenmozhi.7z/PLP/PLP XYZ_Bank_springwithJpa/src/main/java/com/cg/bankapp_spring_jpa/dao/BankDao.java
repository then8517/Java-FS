package com.cg.bankapp_spring_jpa.dao;

import java.util.List;


import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bankapp_spring_jpa.model.Bank;
import com.cg.bankapp_spring_jpa.model.Transaction;

@Repository("bankDAO")
@Transactional
public class BankDao implements IBankDao {


	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	Random random = new Random();
	
	
	public boolean createAccount(Bank bank) {
		entityManager.persist(bank);
		return true;

	}

	
	public int showBalance(long accountNo) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		balance = bank.getBalance();
		return balance;
	}

	
	public int depositBalance(long accountNo, int deposit) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		int balanceCheck = bank.getBalance();
		int balanceAfterDeposit = balanceCheck + deposit;
		bank.setBalance(balanceAfterDeposit);
		Transaction tran = new Transaction();
		tran.setAmount(deposit);
		tran.setTransactionId(random.nextInt(100000));
		tran.setTransactionType("deposit");
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);

		return balanceAfterDeposit;
	}

	
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		int balanceChecking = bank.getBalance();
		int balanceAfterWithdraw = balanceChecking - withdraw;
		bank.setBalance(balanceAfterWithdraw);
		
		Transaction tran = new Transaction();
		tran.setAmount(withdraw);
		tran.setTransactionId(random.nextInt(100000));
		tran.setTransactionType("withdraw");
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);

		return balanceAfterWithdraw;

	}

	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		Bank bank = entityManager.find(Bank.class, accountNo);
		Bank bank1 = entityManager.find(Bank.class, accno);
		if (bank.getBalance() <= amount) {
			b = false;
		} else {
			int sendersBalance = bank.getBalance();
			int  receiversBalance= bank1.getBalance();
			int balanceAfterDeposit = sendersBalance + amount;
			int balanceAfterWithdraw = receiversBalance - amount;
			
			bank1.setBalance( balanceAfterDeposit);
			Transaction transaction = new Transaction();
			transaction.setAmount(amount);
			transaction.setTransactionId(random.nextInt(100000));
			transaction.setTransactionType("fund transfer");
			transaction.setBank(bank1);
			transaction.setFromAccount(accno);
			entityManager.persist(transaction);
			
			bank.setBalance(balanceAfterWithdraw);
			Transaction transaction1 = new Transaction();
			transaction1.setAmount(amount);
			transaction1.setTransactionId(random.nextInt(100000));
			transaction1.setTransactionType("fund transfer");
			transaction1.setBank(bank);
			transaction.setFromAccount(accountNo);
			entityManager.persist(transaction1);
			b = true;
		}
		return b;
	}

	
	public boolean validateAccount(long accountNo, String password) {
		Bank bank1 = entityManager.find(Bank.class, accountNo);
		boolean b = false;
		String pass = bank1.getPassword();
		if (password.equals(pass)) {
			b = true;
		}

		return b;
	}


	public List<Transaction> getTransactions(long accountNo) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		TypedQuery<Transaction> query = entityManager.createQuery("Select t from Transaction as t where t.bank=:bank",
				Transaction.class);
		query.setParameter("bank", bank);
		List<Transaction> transaction = query.getResultList();
		return transaction;
	}

	
}