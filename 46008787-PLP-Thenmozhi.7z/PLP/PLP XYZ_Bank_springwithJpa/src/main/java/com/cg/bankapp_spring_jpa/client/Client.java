package com.cg.bankapp_spring_jpa.client;
import java.util.List;



import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bankapp_spring_jpa.model.Transaction;
import com.cg.bankapp_spring_jpa.service.IBankService;
public class Client {
	
		public static void main(String[] args) {
			
		    Scanner sc = new Scanner(System.in);      
            ApplicationContext applicationcontext = new ClassPathXmlApplicationContext("Beans.xml");
   		    IBankService bankService =  applicationcontext.getBean("bankService",IBankService.class);
	        int option;
			int obj,balance;
			String name,password,contactNumber;
			while(true)
			{
			
				System.out.println("Welcome!!!");
				System.out.println("Please Select an option");
				System.out.println("1.Create an Account");
				System.out.println("2.Check Balance");
				System.out.println("3.Deposit Money");
				System.out.println("4.Withdraw Money ");
				System.out.println("5.Transfer Money ");
				System.out.println("6.Print Transactions");
				System.out.println("7.Exit");
				option = sc.nextInt();
				switch (option) {
				case 1:
					System.out.println("Welcome");
					do
					{
						System.out.println("Enter your name: ");
						name = sc.next();
						obj =bankService.nameValidate(name);
					}
					while(obj!=1);
					do
					{
						System.out.println("Enter your mobile number: ");
						contactNumber = sc.next();
						obj = bankService.mobNoValidate(contactNumber);
					}
					while(obj!=1);
					long accountNumber = (long) (Math.random()*1234);
					do
					{
						System.out.println("Create 4 digit Pin: ");
						password= sc.next();
						obj = bankService.passwordValidate(password);
					}
					while(obj!=1);
					do
					{
						System.out.println("Enter the amount: ");
						balance = sc.nextInt();
						obj = bankService.checkBalance(balance);
					}
					while(obj!=1);
					boolean result =  bankService.createAccount(name,contactNumber,password,accountNumber,balance);
					if(result)
					{
						System.out.println("Your Account has been created successfully: "+accountNumber);
					}
					break;
				case 2:
					System.out.println("Enter the account number: ");
					accountNumber = sc.nextLong();
					System.out.println("Enter your 4 digit Pin");
					password = sc.next();
					boolean bank1= bankService.validateAccount(accountNumber,password);
					if(bank1)
					{
							balance = bankService.showBalance(accountNumber);
							if(balance!=0)
							{
								System.out.println("Your Current account balance is: "+balance);
							}
							else
							{
								System.out.println("Insufficient balance");
							}
					}
					else
					{
						System.out.println("Details invalid..Please check ");
					}
					break;
				
				case 3:
					System.out.println("Enter your account number");
					accountNumber = sc.nextLong();
					System.out.println("Enter your 4 digit Pin");
					password = sc.next();
					boolean bank2= bankService.validateAccount(accountNumber,password);
					if(bank2)
					{
						System.out.println("Enter the amount to be deposited");
						int deposit = sc.nextInt();
						balance = bankService.depositAmount(accountNumber,deposit);
						System.out.println("Amount is deposited to your account");
						System.out.println("your current balance is "+balance);
					}
					else
					{
						System.out.println("The details you have entered are invalid..Check once again..");
					}
					break;
				
				case 4:
					System.out.println("Enter your account number");
					accountNumber = sc.nextLong();
					System.out.println("Enter your 4 digit Pin");
					password = sc.next();
					bank2= bankService.validateAccount(accountNumber,password);
					if(bank2)
					{
						balance = bankService.showBalance(accountNumber);
						System.out.println("Your current balance is "+balance);
						System.out.println("Enter the amount to be withdraw");
						int withdraw = sc.nextInt();
							balance = bankService.withdrawAmount(accountNumber,withdraw);
							if(balance>=0)
							{
								System.out.println("Amount has been withdrawan from your account...");
						
								System.out.println("Your new account balance is "+balance+"\n");
							}
							else
							{
                                 System.out.println("Insufficient Balance..");
							}
						}
						
					
					else
					{
				               System.out.println("Details invalid..Please check..");
					}
					break;
				
				case 5:
					System.out.println("Enter the senders account number");
					accountNumber = sc.nextLong();
					System.out.println("Enter your 4 digit Pin");
					password= sc.next();
					bank2 = bankService.validateAccount(accountNumber,password);
					if(bank2)
					{
						System.out.println("\nEnter the receivers account number");
						long  accno = sc.nextLong();
						System.out.println("Enter the amount to transfer");
						int amount = sc.nextInt();
						boolean transfer = bankService.fundTransfer(accountNumber, accno, amount);
						if(transfer)
						{
							System.out.println(amount+ " amount has been transferred successfully...");
						}
						else
						{
						  System.out.println("Error Occurred ");
						}
					}
					else
					{
						System.out.println(" Details  invalid..Check once again..");
					}
					break;
				
				case 6:
					System.out.println("Enter your account number");
					accountNumber = sc.nextLong();
					System.out.println("Enter your 4 digit Pin");
					password = sc.next();
					bank2 = bankService.validateAccount(accountNumber,password);
					if(bank2)
					{
	                    List<Transaction> transaction=bankService.getTransaction(accountNumber);

						System.out.println("Transaction Statement\n");

						for(Transaction tran:transaction)
						{
							System.out.println(tran);
						}
					}
					else 
					{
						System.out.println(" Details invalid..Check once again..");
					}
					break;
				
				case 7: 
					System.out.println("Thank you");
					System.out.println("Visit Again");
					System.exit(0);
					break; 
					
				default: 
                System.out.println("Please choose from the available options");
                break;
	            }
			}
	}
}
