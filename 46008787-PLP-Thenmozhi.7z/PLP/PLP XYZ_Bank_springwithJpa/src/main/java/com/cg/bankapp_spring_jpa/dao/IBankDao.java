package com.cg.bankapp_spring_jpa.dao;

import java.util.List;


import com.cg.bankapp_spring_jpa.model.Bank;
import com.cg.bankapp_spring_jpa.model.Transaction;

public interface IBankDao {
   boolean createAccount(Bank bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<Transaction> getTransactions(long accountNo) ;
	
}
