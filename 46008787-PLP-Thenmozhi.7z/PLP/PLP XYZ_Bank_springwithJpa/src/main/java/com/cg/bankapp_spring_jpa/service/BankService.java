package com.cg.bankapp_spring_jpa.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapp_spring_jpa.dao.BankDao;
import com.cg.bankapp_spring_jpa.model.Bank;
import com.cg.bankapp_spring_jpa.model.Transaction;

class MyException extends Exception
{
	private static final long serialVersionUID = 1L;
	String s1;
	MyException(String s)
	{
		 s1=s;
	}
	public String toString()
	{
		return (s1);
	}
}
@Service("bankService")
public class BankService implements IBankService
{
	int balance;
	@Autowired
	private BankDao bankDao;

	// creating account
	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance) {
		
		Bank bank = new Bank();
	    bank.setName(name);
	    bank.setPhoneNo(phoneNo);
	    bank.setPassword(password);
	    bank.setAccountNo(accountNo);
	    bank.setBalance(balance);
	    
	    boolean result = bankDao.createAccount(bank);
		
	    return result;
	}

	// showing balance for the account number provided
	public int showBalance(long accountNo) {
	
		balance = bankDao.showBalance(accountNo);
	
		 return balance;
	}

// depositing amount in a particular account
	public int depositAmount(long accountNo, int deposit) {
		int balance;
	
		 balance = bankDao.depositBalance(accountNo, deposit);
		 return balance;
	}

	// withdrawing amount from a particular account
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance;
		
		 balance = bankDao.withdrawAmount(accountNo,withdraw);
		 return balance;
	}

	// transferring fund from one account to another
	public boolean fundTransfer(long accountNo, long accno, int amount) {
	
		boolean fund = bankDao.fundTransfer(accountNo,accno,amount);
	      return fund;
	}

	// account number validation
	public boolean validateAccount(long accountNo, String password) {
	
		boolean validate = bankDao.validateAccount(accountNo,password);
	    return validate;
	}

	
	// Get the list of transactions done for a particular account number
	public List<Transaction> getTransaction(long accountNo) {

	   List<Transaction> listOfTransactions = bankDao.getTransactions(accountNo);
	
	   return listOfTransactions;
	}
	
	//password validation

	public int passwordValidate(String password) {
		try
		{
		if(password.length()<5)
			return 1;
		else
			throw new MyException("Pin number Should Be 4 digits..");
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
			return 0;
	}

	
	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}
	
	
	//validation for mobile number
	
	public int mobNoValidate(String phoneNo) {
		try
		{
			if(phoneNo.matches("[6-9][0-9]{9}"))
					return 1;
			else
				throw new MyException("Mobile Number is not valid.. Please enter correct format");
				
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}

	
	// validation for name
	
	public int nameValidate(String name) {
		try
		{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		
		else
		throw new MyException("Please enter correctly...Name Should Start With Capital Letter..");
	}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}
	
}