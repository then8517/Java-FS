package com.cg.absdemo;

abstract class StudentDetails {
	
	protected String name;
	protected int studID;
	
	public StudentDetails(String name, int studID) {
		this.name = name;
		this.studID = studID;
	}
	public abstract void display();
	
}
