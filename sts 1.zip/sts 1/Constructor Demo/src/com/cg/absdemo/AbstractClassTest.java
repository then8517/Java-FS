package com.cg.absdemo;

public class AbstractClassTest {

	public static void main(String[] args) {
		StudentDetails stuObj = new Student("Rajesh", 1001);
		stuObj.display();

	}

}
