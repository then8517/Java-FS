package com.cg.absdemo;

public class Student extends StudentDetails{

	public Student(String name, int studID) {
		super(name, studID);
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Student Name : "+this.name+ "\nStudent ID : "+this.studID);
				
		
	}

	
}
