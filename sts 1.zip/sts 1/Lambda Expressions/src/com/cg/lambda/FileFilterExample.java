package com.cg.lambda;

import java.io.File;
import java.io.FileFilter;


public class FileFilterExample {
	public static void main(String[] args) {
		
//		FileFilter filter = new FileFilter() {
//			
//			@Override
//			public boolean accept(File pathname) {
//				
//				return pathname.getName().endsWith(".java");
//			}
//		};
		FileFilter lambdaFilter = (File pathname) -> pathname.getName().endsWith(".java");
		File dir = new File("D:/tmp");
		File[] file = dir.listFiles(lambdaFilter);

			System.out.println(file);
		
	}
}
