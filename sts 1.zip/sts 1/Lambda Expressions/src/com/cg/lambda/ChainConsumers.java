package com.cg.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ChainConsumers {
	public static void main(String[] args) {
		List<String> strings = Arrays.asList("One", "Two", "Three", "Four", "Five");
		List<String> result = new ArrayList<>();
		
		Consumer<String> s1 = System.out::println;
		Consumer<String> s2 = result::add;
		
		strings.forEach(s1.andThen(s2));
		System.out.println("The result size is: "+result.size());
		
	}
}
