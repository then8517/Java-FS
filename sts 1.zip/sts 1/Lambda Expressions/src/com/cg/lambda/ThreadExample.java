package com.cg.lambda;

public class ThreadExample {
	public static void main(String[] args) {
		Runnable runObj = new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < 3; i++) {
					System.out.println("I am running in :"+Thread.currentThread()
					.getName());
				}
			}
		};
		//Lambda Expression
		Runnable lambdaRunObj = () -> {
			for (int i = 0; i < 3; i++) {
				System.out.println("I am running in :"+Thread.currentThread()
				.getName());
			}
		};
		Thread thread = new Thread(lambdaRunObj) ;
		thread.start();

	}

}
