package com.cg.lambda;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample {
	public static void main(String[] args) {
		Comparator<String> compObj = new Comparator<String>() {

			@Override
			public int compare(String string1, String string2) {

				return Integer.compare(string1.length(), string2.length());
			}
		};
		
		// Lambda Expression
				Comparator<String> lambdaCompObj = (String string1, String string2) 
						-> Integer.compare(string1.length(),
						string2.length());
						
		List<String> list = Arrays.asList("***", "****", "**", "*");
		list.sort(lambdaCompObj);

		

		for (String s : list) {
			System.out.println(s);
		}
	}
}
