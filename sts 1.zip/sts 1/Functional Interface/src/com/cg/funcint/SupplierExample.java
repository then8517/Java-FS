package com.cg.funcint;

import java.util.function.Supplier;

/*@FunctionalInterface
public interface Supplier<T>{
T get();
}
*/

public class SupplierExample {
	public static void main(String[] args) {

		Supplier<Double> randomValue = () -> Math.random();

		System.out.println(randomValue.get());

		Supplier<Student> student1 = () -> new Student(1001, "Rajesh", "M", 19);
		Supplier<Student> student2 = () -> new Student(1002, "Ramesh", "F", 21);

		System.out.println(student1.get());
		System.out.println(student2.get());
	}
}
/*A functional interface is an interface that contains only one abstract method.
 *  They can have only one functionality to exhibit. From Java 8 onwards, 
 * lambda expressions can be used to represent the instance of a functional interface.*/
