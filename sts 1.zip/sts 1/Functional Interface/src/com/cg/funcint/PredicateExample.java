package com.cg.funcint;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/*@FunctionalInterface
  public interface Predicate<T>{
  boolean test(T t);
  }*/

public class PredicateExample {
	public static void main(String[] args) {
		Predicate<Integer> calcLess = age -> age > 18;
		
		System.out.println(calcLess.test(10));
		System.out.println(calcLess.test(18));  //test(int 18)
		
		List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		Predicate<Integer> number1 = num -> num > 4;
		Predicate<Integer> number2 = num -> num < 10;
		
		list.stream().filter(number1).forEach(a -> System.out.print(a+" ")); 
		System.out.println();
		
		list.stream().filter(number1.and(number2)).forEach(a -> System.out.print(a+" ")); //.and()
		
		System.out.println();
		list.stream().filter(number1.negate()).forEach(a -> System.out.print(a+" ")); //negate()
	}
}
/* Predicate<T> is a generic functional interface representing a single argument function 
 * that returns a boolean value. It is located in the java.util.function package.
 *  It contains a boolean test(T t) method that evaluates the predicate on the given argument.*/
 