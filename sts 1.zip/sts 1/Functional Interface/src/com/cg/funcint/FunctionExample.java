package com.cg.funcint;

import java.util.function.Function;

/*@FunctionalInterface
public interface Function<T, R>{
R apply(T t);
}
*/
public class FunctionExample {

	public static void main(String[] args) {
		
		Function<Integer, Integer> number1 = (num1) -> (num1 + 20);
		Function<Integer, Integer> number2 = (num1) -> (num1 * 2);
		
		int result = number1.apply(50); //apply(int 50)
		
		System.out.println(result);
		
		System.out.println(number1.andThen(number2).apply(50));  //andThen()
	}

}
