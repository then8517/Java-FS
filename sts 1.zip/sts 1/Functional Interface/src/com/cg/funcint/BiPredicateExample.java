package com.cg.funcint;

import java.util.function.BiPredicate;

/*@FunctionalInterface
public interface BiPredicate<T, U>{
boolean test(T t, U u);
}
*/
public class BiPredicateExample {
	public static void main(String[] args) {
		BiPredicate<String, String> string = (string1, string2) -> (string1 == string2);

		System.out.println("Does the Strings are equal:"+string.test("Hello", "Hello")); // test()
		System.out.println("Does the Strings are equal:"+string.test("Hello", "hello"));

		BiPredicate<Integer, Integer> number1 = (x, y) -> x > y;
		BiPredicate<Integer, Integer> number2 = (x, y) -> x == y;

		System.out.println(number1.and(number2).test(20, 20)); // .and()
		System.out.println(number1.or(number2).test(40, 20)); // .or()
		System.out.println(number1.negate().test(40, 20)); // .negate()
	}
}
