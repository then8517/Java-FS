package com.cg.funcint;

import java.util.function.BiFunction;

/*@FunctionalInterface
public interface BiFunction<T, U, R>{
R apply(T t, U u);
}
Represents a function that accepts two arguments and produces a result of type 3rd parameter*/
public class BiFunctionExample {

	public static void main(String[] args) {

		BiFunction<Integer, Integer, Double> resultDouble = (num1, num2) -> Math.pow(num1, num2);

		System.out.println(resultDouble.apply(4, 2));

		BiFunction<Integer, Integer, Integer> resultInteger = (x1, x2) -> x1 + x2;

		System.out.println(resultInteger.apply(2, 3));
	}

}
