package com.cg.funcint;

import java.util.function.BiConsumer;

/*@FunctionalInterface
public interface BiConsumer<T, U>{
void accept(T t, U u);
}
*/
public class BiConsumerExample {

	public static void main(String[] args) {

		BiConsumer<Integer, String> consumer = (a, b) -> System.out.println(a + b);

		consumer.accept(1, " Hello World!"); // accept()
		consumer.accept(2, " Hello India!");

		BiConsumer<Integer, Integer> addition = (a, b) -> System.out.println(a + b);
		BiConsumer<Integer, Integer> subtraction = (a, b) -> System.out.println(a - b);

		addition.andThen(subtraction).accept(10, 6); // andThen()
	}

}
