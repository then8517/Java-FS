package com.cg.funcint;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/*@FunctionalInterface
public interface Consumer<T>{
void accept(T t);
}
*/

public class ConsumerExample {
	public static void main(String[] args) {
		
		Consumer<String> display = a -> System.out.println(a);
		
		display.accept("Hello World!");
		
		Consumer<List<Integer>> multiply = list -> {
			for(int i = 0; i<list.size(); i++)
				list.set(i, 2*list.get(i));
		};
			
		Consumer<List<Integer>> displayList = list -> list.stream()
				                                     .forEach(a -> System.out.println(a+ " "));
		List<Integer> list = new ArrayList<Integer>();
		list.add(2);
		list.add(4);
		list.add(6);
		
		multiply.accept(list);
		displayList.accept(list);
		
//		multiply.andThen(displayList).accept(list);
	}
}
/*It has a method void accept(T t)
 * Does not return anything
 * Accepts one argument
 * It also has another method andThen()*/
 