package com.cg.queue;

import java.util.ArrayDeque;
import java.util.Queue;

public class HelpDesk {
	final Queue<Enquiry> enquiries = new ArrayDeque<>();
	public void enquire(final Customer customer, final Category category) {
		enquiries.offer(new Enquiry(customer, category));
	}
	public void processAllEnquires() {
		//  while(!enquiries.isEmpty()) {    Can be in another way
		
			Enquiry enquiry;
			while((enquiry = enquiries.poll()) != null) {  // enquiry checks for null
			enquiry.getCustomer().reply("Check by switching on and off once again");
		}
	}
	public static void main(String[] args) {
		HelpDesk helpObj = new HelpDesk();
		helpObj.enquire(Customer.JACK, Category.COMPUTER);
		helpObj.enquire(Customer.JILL, Category.PRINTER);
		helpObj.processAllEnquires();
	}
}
