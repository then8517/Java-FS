package com.cg.queue;

public enum Category {
	PRINTER,
	COMPUTER,
	LAPTOP,
	TABLET
}
