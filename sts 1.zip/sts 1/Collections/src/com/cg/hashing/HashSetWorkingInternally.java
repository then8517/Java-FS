package com.cg.hashing;

import java.util.HashSet; 

public class HashSetWorkingInternally {
	// Java program to demonstrate 
	// internal working of HashSet 
		public static void main(String args[]) 
		{ 
			// creating a HashSet 
			HashSet hs = new HashSet();  
			/* it internally creates a HashMap and 
			 * if we insert an element into this HashSet using add() method, 
			 * it actually call put() method on internally created HashMap object 
			 * with element you have specified*/
			
			// adding elements to hashset 
			// using add() method 
			boolean b1 = hs.add("Hello"); 
			boolean b2 = hs.add("HelloWorld"); 
			
			// adding duplicate element 
			boolean b3 = hs.add("Hello"); 
			
			// printing b1, b2, b3 
			System.out.println("b1 = "+b1); 
			System.out.println("b2 = "+b2); 
			System.out.println("b3 = "+b3); 
			
			// printing all elements of hashset 
			System.out.println(hs); 
				
		} 
	} 


