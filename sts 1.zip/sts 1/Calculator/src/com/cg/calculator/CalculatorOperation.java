package com.cg.calculator;

public class CalculatorOperation {
	double[] number1 = { 100.0, 50.0, 25.0, 20.0 };
	double[] number2 = { 150.0, 20.0, 5.0, 2.0 };
	static char[] operation = { 'a', 's', 'd', 'm' };
	double[] result = new double[operation.length];

	public static void main(String[] args) {
		double[] number1 = { 100.0, 50.0, 25.0, 20.0 };
		double[] number2 = { 150.0, 20.0, 5.0, 2.0 };
		char[] operation = { 'a', 's', 'd', 'm' };
		double[] result = new double[operation.length];
		
		for (int i = 0; i < operation.length; i++) {
			switch (operation[i]) {
			case 'a': {
				result[i] = number1[i] + number2[i];
				break;
			}
			case 's': {
				result[i] = number1[i] - number2[i];
				break;
			}
			case 'd': {
				result[i] = number1[i] / number2[i];
				break;
			}
			case 'm': {
				result[i] = number1[i] * number2[i];
				break;
			}
			default:
				result[i] = 0.0d;
				System.err.println("Something went wrong");
			}
		}
		for(double theResult : result) {
			System.out.println("The Result is: "+theResult);
		}
		
	}
}
