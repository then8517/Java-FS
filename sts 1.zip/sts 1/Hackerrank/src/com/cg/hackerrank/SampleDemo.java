package com.cg.hackerrank;

public class SampleDemo {

}
