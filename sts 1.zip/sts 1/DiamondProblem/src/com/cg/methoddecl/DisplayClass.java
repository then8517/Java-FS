package com.cg.methoddecl;

public class DisplayClass implements IDisplay1,IDisplay2 {

	@Override
	public String disp() {
		String op = IDisplay1.super.disp();
		System.out.println(op);
		return "Success";
	}
	public static void main(String[] args) {
		DisplayClass displayObject = new DisplayClass();
		String output = displayObject.disp();
		System.out.println(output);
	}
}
/* When two interfaces have the same method signature where a class implements both the interfaces.
 *Then the method in the specific interface must be called explicitly by using super keyword.
 * 
 * 
 *
 * */
 