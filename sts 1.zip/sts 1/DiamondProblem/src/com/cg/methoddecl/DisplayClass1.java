package com.cg.methoddecl;

public class DisplayClass1 {
	public String disp() {
		return "In DisplayClass1";
	}
}
