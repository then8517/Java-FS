package com.cg.methoddecl;

public interface IDisplay1 {
	default public String disp() {
		return "In IDisplay1 interface";
	}
}
