package com.cg.methoddecl;

public class DisplayClass2 extends DisplayClass1 implements IDisplay2 {

	public static void main(String[] args) {
		DisplayClass2 displayObject = new DisplayClass2();
		String output = displayObject.disp();
		System.out.println(output);
	}
}
//When the class extends class and also implement interface which has same method signature
//Then it executes the base class method, when the default method is added in interface 
//it may happen to have a same method in class