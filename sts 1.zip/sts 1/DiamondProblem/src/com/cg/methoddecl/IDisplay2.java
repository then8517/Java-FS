package com.cg.methoddecl;

public interface IDisplay2 {
	default public String disp() {
		return "In IDisplay2 interface";
	}
}
