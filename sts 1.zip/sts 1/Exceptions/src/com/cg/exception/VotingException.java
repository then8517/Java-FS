package com.cg.exception;

public class VotingException extends Exception {
	VotingException(String message){
		super(message);
	}
	VotingException(String message, Throwable cause){
		super(message, cause);
	}
}
