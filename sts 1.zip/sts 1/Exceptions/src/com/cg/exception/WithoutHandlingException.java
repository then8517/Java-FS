package com.cg.exception;

public class WithoutHandlingException {
	public static void main(String[] args) {
		int divide = 18 / 0;
		System.out.println(divide);
	}
}
