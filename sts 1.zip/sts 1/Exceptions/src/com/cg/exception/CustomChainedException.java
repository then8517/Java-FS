package com.cg.exception;

import java.util.Scanner;

public class CustomChainedException {
	static int age;
	static Scanner scan = new Scanner(System.in);

	public static void checkVotingEligibility(int age) throws NoVotingEligibilityException {
		try {
			if (age < 18)
				noEligibleToVote();
			else
				System.out.println("You are eligible to vote");
		} catch (VotingException e) {
			throw new NoVotingEligibilityException("You are not eligible to vote", e);
		}
	}

	public static void noEligibleToVote() throws VotingException {
		throw new VotingException("You are under 18");
	}

	public static void main(String[] args) throws Exception {
		System.out.println("Enter your age :");
		age = scan.nextInt();
		checkVotingEligibility(age);
	}

}
//Chained Exception helps to identify a situation in which one exception causes another Exception in an application.