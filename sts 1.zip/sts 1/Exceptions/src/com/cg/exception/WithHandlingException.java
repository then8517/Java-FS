package com.cg.exception;

public class WithHandlingException {
	public static void main(String[] args) {
		try {
			int invalidDivide = 18 / 0;
			System.out.println(invalidDivide);
			
		}catch(ArithmeticException e) {
			e.getSuppressed();
			System.out.println("Supressed");
		}finally {
			throw new NumberFormatException();
		}
//		int validDivide = 18 / 2;
//		System.out.println("Valid Divide: "+validDivide);

	}
}
