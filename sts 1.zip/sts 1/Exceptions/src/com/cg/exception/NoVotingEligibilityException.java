package com.cg.exception;

public class NoVotingEligibilityException extends Exception {
	NoVotingEligibilityException(String message){
		super(message);
	}
	NoVotingEligibilityException(String message, Throwable cause){
		super(message, cause);
	}
}
