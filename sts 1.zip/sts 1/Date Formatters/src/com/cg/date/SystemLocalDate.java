package com.cg.date;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SystemLocalDate {
	public static void main(String[] args) {
	LocalDate today = LocalDate.now();
	System.out.println(today);
	
	System.out.println(LocalDate.from(DateTimeFormatter.ISO_LOCAL_DATE.parse("2018-03-09")).plusDays(3));

	System.out.println(today.from(DateTimeFormatter.ISO_LOCAL_DATE.parse("2020-03-09")).plusDays(5));
	
}
}
