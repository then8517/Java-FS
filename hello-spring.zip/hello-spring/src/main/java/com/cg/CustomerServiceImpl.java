package com.cg;

public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository repo;

	public CustomerServiceImpl() {

		repo = new JDBCCustomerRepositoryImpl();

	}

	public CustomerServiceImpl(CustomerRepository repository) {
		System.out.println("repository injected into service via constructor injection");
		repo = new JDBCCustomerRepositoryImpl();
	}

	public void setRepository(CustomerRepository repository) {
		System.out.println("repository injected into service via setter injection");
		this.repo = repository;
	}

	@Override
	public String find(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
