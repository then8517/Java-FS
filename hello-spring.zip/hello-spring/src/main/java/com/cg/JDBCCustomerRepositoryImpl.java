package com.cg;

public class JDBCCustomerRepositoryImpl implements CustomerRepository{

	@Override
	public String findById(int id) {
		// TODO Auto-generated method stub
		return "John";
	}
}
