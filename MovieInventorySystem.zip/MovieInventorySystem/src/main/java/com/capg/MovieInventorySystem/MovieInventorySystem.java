package com.capg.MovieInventorySystem;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class MovieInventorySystem {
	WebDriver driver;
	@FindBy(id = "Text24")
	WebElement movieId;
	@FindBy(id = "Text1")
	WebElement movieTitle;
	@FindBy(id = "Text12")
	WebElement releaseYear;
	@FindBy(id = "Text14")
	WebElement director;
	@FindBy(id = "Text15")
	WebElement movieDuration;
	@FindBy(id = "Select12")
	WebElement language;
	@FindBy(id = "Select9")
	WebElement movieRating;
	@FindBy(id = "Button4")
	WebElement AddMovieBtn;
	
	public MovieInventorySystem(WebDriver btn) {
		driver = btn;
		PageFactory.initElements(driver, this);
	}

	

	public String getMovieId() {
		return movieId.getAttribute("value");
	}

	public void setMovieId(String movieId) {
		this.movieId.sendKeys(movieId);;
	}

	public String getMovieTitle() {
		return movieTitle.getAttribute("value");
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle.sendKeys(movieTitle);
	}

	public String getReleaseYear() {
		return releaseYear.getAttribute("value");
	}

	public void setReleaseYear(String releaseYear) {
		this.releaseYear.sendKeys(releaseYear);
	}

	public String getDirector() {
		return director.getAttribute("value");
	}

	public void setDirector(String director) {
		this.director.sendKeys(director);
	}

	public String getMovieDuration() {
		return movieDuration.getAttribute("value");
	}

	public void setMovieDuration(String movieDuration) {
		this.movieDuration.sendKeys(movieDuration);
	}

	public int getLanguage() {
		return Integer.parseInt(new Select(this.language).getFirstSelectedOption().getText());
	}

	public void setLanguage(String language) {
		new Select(this.language).selectByVisibleText(language);
	}

	public int getMovieRating() {
		return Integer.parseInt(new Select(this.movieRating).getFirstSelectedOption().getText());
	}

	public void setMovieRating(String movieRating) {
		new Select(this.movieRating).selectByVisibleText(movieRating);
	}

	public void clickButton( ) {
		this.AddMovieBtn.click();
	}
	
	
	
}
