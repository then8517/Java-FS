package com.capg.MovieInventorySystem;

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MovieInventorySystemStepDef {
	
	static WebDriver driver;
	static MovieInventorySystem mis;
	
	@BeforeClass
	public static void before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\MovieInventorySystem\\Drivers\\chromedriver.exe");		
	    driver = new ChromeDriver();
	}
	
	@Test
	@Given("^User is on Movie Inventory System page$")
	public void user_is_on_Movie_Inventory_System_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:\\Selenium\\MovieInventorySystem\\Drivers\\MovieInventorySystem.html");
		 driver.manage().window().maximize();
		 mis = new MovieInventorySystem(driver);
		 mis.clickButton();
		 select_Add_Movie_link_without_entering_Movie_ID();
	}

	@When("^select 'Add Movie' link without entering 'Movie ID'$")
	public void select_Add_Movie_link_without_entering_Movie_ID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		mis.clickButton();
		//String actualMessage = driver.switchTo().alert().getText();
		//String expectedMessage = "Please fill out this field.";
		//Assert.assertEquals(actualMessage, expectedMessage);
		please_fill_out_this_field_message_should_display();
	}

	@Then("^'Please fill out this field\\.' message should display$")
	public void please_fill_out_this_field_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//driver.switchTo().alert().dismiss();
		mis.setMovieId("1234");
		mis.clickButton();
		user_select_Add_Movie_button_without_entering_Movie_Title();
	}

	@When("^User select 'Add Movie' button without entering 'Movie Title'$")
	public void user_select_Add_Movie_button_without_entering_Movie_Title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//String actualMessage = driver.switchTo().alert().getText();
		//String expectedMessage = "Please fill out this field.";
		//Assert.assertEquals(actualMessage, expectedMessage);
		mis.setMovieTitle("3idiots");
		user_select_Add_Movie_button_without_entering_Release_Year();
	}

	@When("^User select 'Add Movie' button without entering 'Release Year'$")
	public void user_select_Add_Movie_button_without_entering_Release_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

//		user_select_Add_Movie_button_without_entering_Director();
		//String actualMessage = driver.switchTo().alert().getText();
		//String expectedMessage = "Please fill out this field.";
		//Assert.assertEquals(actualMessage, expectedMessage);
	// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		mis.setReleaseYear("2012");
//		mis.clickButton();
		mis.setReleaseYear("2012");
		
		 user_select_Add_Movie_button_without_entering_Director();
	}

	@When("^User select 'Add Movie' button without entering 'Director'$")
	public void user_select_Add_Movie_button_without_entering_Director() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		String actualMessage = driver.switchTo().alert().getText();
//		String expectedMessage = "Please fill out this field.";
//		Assert.assertEquals(actualMessage, expectedMessage);
		
		// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		mis.setDirector("YashRaj");
//		mis.clickButton();
		
		mis.setDirector("Yashraj");
		
		user_select_Add_Movie_button_without_entering_Movie_Duration();
	}

	@When("^User select 'Add Movie' button without entering 'Movie Duration'$")
	public void user_select_Add_Movie_button_without_entering_Movie_Duration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

//		String actualMessage = driver.switchTo().alert().getText();
//		String expectedMessage = "Please fill out this field.";
//		Assert.assertEquals(actualMessage, expectedMessage);
		// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		mis.setMovieDuration("2hrs:30min");
//		mis.clickButton();
		mis.setMovieDuration("2hrs:30min");
		user_select_Add_Movie_button_without_entering_Language();
	}

	@When("^User select 'Add Movie' button without entering 'Language'$")
	public void user_select_Add_Movie_button_without_entering_Language() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		String actualMessage = driver.switchTo().alert().getText();
//		String expectedMessage = "Please fill out this field.";
//		Assert.assertEquals(actualMessage, expectedMessage);
		// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		mis.setLanguage("hindi");
//		mis.clickButton();
		
		mis.setLanguage("hindi");
		user_select_Add_Movie_button_without_entering_Movie_Rating();
	}

	@When("^User select 'Add Movie' button without entering 'Movie Rating'$")
	public void user_select_Add_Movie_button_without_entering_Movie_Rating() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		String actualMessage = driver.switchTo().alert().getText();
//		String expectedMessage = "Please fill out this field.";
//		Assert.assertEquals(actualMessage, expectedMessage);
		// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		mis.setMovieRating("5");
//		mis.clickButton();
		mis.setMovieRating("5");
		Thread.sleep(1000);
		user_select_Add_Movie_button_after_entering_Valid_set_of_information();
	}

	@When("^User select 'Add Movie' button after entering 'Valid set of information'$")
	public void user_select_Add_Movie_button_after_entering_Valid_set_of_information() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		String actualMessage = driver.switchTo().alert().getText();
//		String expectedMessage = "Please fill out this field.";
//		Assert.assertEquals(actualMessage, expectedMessage);
		// **Within the then part** //
//		driver.switchTo().alert().dismiss();
//		
//		mis.clickButton();
		Thread.sleep(1000);
		movie_added_successfully_message_should_display();
		
	}
	

	@Then("^'Movie added successfully'  message should display$")
	public void movie_added_successfully_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		//driver.switchTo().alert().dismiss();
	}

	@AfterClass
	public static void after() {
		
		driver.close();
	}
	
	

}
