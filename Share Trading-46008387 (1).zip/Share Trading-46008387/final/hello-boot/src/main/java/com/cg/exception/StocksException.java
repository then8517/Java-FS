package com.cg.exception;

public class StocksException extends Exception {
	public StocksException() {
		super();
	}

	public StocksException(String message) {
		super(message);
	}

}
