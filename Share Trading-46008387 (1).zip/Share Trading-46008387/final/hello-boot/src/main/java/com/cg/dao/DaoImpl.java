package com.cg.dao;
import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

 

import org.springframework.stereotype.Repository;

import com.cg.model.Stocks;


@Repository
public class DaoImpl implements IDao{
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Transactional
    public Stocks createStock(Stocks stock) {
        
        entityManager.persist(stock);
        
        return stock;
    }
    
    @Transactional
    public Stocks deleteStock(int id)
    {
        Stocks stock=entityManager.find(Stocks.class, id);
        entityManager.remove(stock);
        return stock;
    }
    
    @Transactional
    public Stocks getSingleStock(int id) {
        Stocks stock=entityManager.find(Stocks.class, id);
        return stock;
    }
    
    @Transactional
    public List<Stocks> viewAllStock() {
        Query query = entityManager.createQuery("from Stocks");
        return query.getResultList();
    }
    
    @Transactional
    public Stocks updateStock(Stocks stock) {
        entityManager.merge(stock);
        return stock;
    }
    public String m1() {
        
        System.out.println("entityManager"+ entityManager);
        return null;
        
    }
    
}
