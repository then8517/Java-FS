package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.DaoImpl;
import com.cg.dao.IDao;
import com.cg.model.Stocks;

@Service
public class StockServiceImpl implements StockService {
	@Autowired
	 IDao dao=new DaoImpl();

	@Override
	public Stocks createStock(Stocks stock) {
		// TODO Auto-generated method stub
		return dao.createStock(stock);
	}

	@Override
	public Stocks deleteStock(int id) {
		// TODO Auto-generated method stub
		return dao.deleteStock(id);
	}

	@Override
	public Stocks getSingleStock(int id) {
		// TODO Auto-generated method stub
		return dao.getSingleStock(id);
	}

	@Override
	public List<Stocks> viewAllStock() {
		// TODO Auto-generated method stub
		return dao.viewAllStock();
	}

	@Override
	public Stocks updateStock(Stocks stock) {
		// TODO Auto-generated method stub
		return dao.updateStock(stock);
	}

}
