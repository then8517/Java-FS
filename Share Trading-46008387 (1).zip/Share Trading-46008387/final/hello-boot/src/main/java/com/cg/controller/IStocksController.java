package com.cg.controller;

import java.util.List;


import org.springframework.web.bind.annotation.RequestBody;

import com.cg.model.Stocks;

public interface IStocksController {
	public List<Stocks> list();

	public Stocks create(Stocks stock);

	public Stocks get( int id);

	public Stocks update(int id, @RequestBody Stocks stock);

	public Stocks delete(int id);
}
