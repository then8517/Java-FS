package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.model.Stocks;
import com.cg.service.StockService;
import com.cg.service.StockServiceImpl;

@RestController
@RequestMapping("api/v1")
public class StocksController {
	
	@Autowired
	StockService service=new StockServiceImpl();
	
	@RequestMapping(method = RequestMethod.GET, value = "ViewAllStock")
	public List<Stocks> list(){
		
		return service.viewAllStock();
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "CreateStock")
	public Stocks create(@RequestBody Stocks stock) {
		
		return service.createStock(stock);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "FindSingleStock/{id}")
	public Stocks get(@PathVariable("id") int id){
		
		return service.getSingleStock(id);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "UpdateStock/{id}")
    public Stocks update(@PathVariable("id") int id, @RequestBody Stocks stock) {
        return service.updateStock(stock);
    }
	
	@RequestMapping(method = RequestMethod.DELETE, value = "DeleteStock/{id}")
    public Stocks delete(@PathVariable("id") int id) {
        return service.deleteStock(id);
    }
		
}
