package com.cg.dao;

import java.util.List;

import com.cg.model.Stocks;

public interface IDao {
	public Stocks createStock(Stocks stock);

	public Stocks deleteStock(int id);

	public Stocks getSingleStock(int id);

	public List<Stocks> viewAllStock();

	public Stocks updateStock(Stocks stock);
}
