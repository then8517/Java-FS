package com.cg.forum.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.forum.beans.Admin;
import com.cg.forum.beans.GroupComment;
import com.cg.forum.beans.GroupMembers;
import com.cg.forum.beans.Groups;
import com.cg.forum.beans.GroupsTopic;
import com.cg.forum.beans.RequestStatus;
import com.cg.forum.services.IGroupService;

@CrossOrigin("http://localhost:4200")
@RestController
public class GroupsController {
	@Autowired
	IGroupService groupService;
	@RequestMapping(value="/creategroup" ,method=RequestMethod.POST)
	public Groups createGroup(@RequestBody Groups groups){
		return groupService.createGroup(groups);
		}
		
	@RequestMapping(value="/getgroupdetails/{groupId}" ,method=RequestMethod.GET)
	public Groups getGroupDetails(@PathVariable int groupId){
		return groupService.getGroupById(groupId);
		}
	@RequestMapping(value="/viewalldetails",method=RequestMethod.GET)
	public List<Groups> viewAllDetails()
	{
		return groupService.viewAllGroups();
	}
	@RequestMapping(value="/addtopic" ,method=RequestMethod.POST)	
	public GroupsTopic assignTopic(@RequestBody GroupsTopic topic) {
		return groupService.addTopic(topic);
		
	}
	@RequestMapping(value="/gettopicdetails/{topicId}" ,method=RequestMethod.GET)	
	public GroupsTopic getTopicDetails(@PathVariable int topicId) {
		return groupService.getTopicById(topicId);
		
	}
	@RequestMapping(value="/viewalltopics",method=RequestMethod.GET)
	public List<GroupsTopic> viewAllTopicsDetails()
	{
		return groupService.viewAllTopics();
	}
	@RequestMapping(value="/postcomment" ,method=RequestMethod.POST)	
	public GroupComment postComment(@RequestBody GroupComment comment ) {
		return groupService.postComment(comment);
		
	}
	@RequestMapping(value="/postedcomments",method=RequestMethod.GET)
	public List<GroupComment> postedComments()
	{
		return groupService.postedComments();
	}
	@RequestMapping(value="/postrequest" ,method=RequestMethod.POST)
	public GroupMembers postRequest(@RequestBody GroupMembers request) {
		return groupService.postRequest(request);	}
	@RequestMapping(value="/getallrequest",method=RequestMethod.GET)
	public List<GroupMembers> getAllRequest()
	{
		return groupService.getAllRequest();
	}
	
	@RequestMapping(value="/postrequeststatus" ,method=RequestMethod.POST)
	public RequestStatus postStatus(@RequestBody RequestStatus status) {
		return groupService.postStatus(status);	}
	
	@RequestMapping(value="/getstatusdetails/{memberName}" ,method=RequestMethod.GET)	
	public String checkStatusById(@PathVariable String memberName) {
		return groupService.checkStatusById(memberName);
		
	}
	@RequestMapping(value="/removemember/{memberId}",method=RequestMethod.DELETE)
	public ResponseEntity<Object> removeMember(@PathVariable int memberId)
	{
		return groupService.removeMember(memberId);
	}

}
