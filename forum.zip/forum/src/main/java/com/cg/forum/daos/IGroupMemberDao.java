package com.cg.forum.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.forum.beans.GroupMembers;

public interface IGroupMemberDao extends JpaRepository<GroupMembers,Integer>{

}
