package com.cg.forum.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.forum.beans.Admin;
import com.cg.forum.beans.GroupComment;
import com.cg.forum.beans.GroupMembers;
import com.cg.forum.beans.Groups;
import com.cg.forum.beans.GroupsTopic;
import com.cg.forum.beans.RequestStatus;

public interface IGroupService {
	public Groups createGroup(Groups groups);
	public Groups getGroupById(int groupId);
	public List<Groups> viewAllGroups();
	public GroupsTopic addTopic(GroupsTopic topic);
	public GroupsTopic getTopicById(int topicId);
	public List<GroupsTopic> viewAllTopics();
	public GroupComment postComment(GroupComment comment);
	public GroupMembers postRequest(GroupMembers request);
	public List<GroupMembers> getAllRequest();
	public RequestStatus postStatus(RequestStatus status);
	public String checkStatusById(String memberName);
	public List<GroupComment> postedComments();
	public ResponseEntity<Object> removeMember(int memberId);
}
