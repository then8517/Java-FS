package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAConfig {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("jpademo");

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		
		Books obj1 = new Books(1001, "Java HeadFirst", "Bert Bates and Kathy Sierra", 690, "Java");
		
		entityManager.persist(obj1);

		entityManager.getTransaction().commit();
	}

}
