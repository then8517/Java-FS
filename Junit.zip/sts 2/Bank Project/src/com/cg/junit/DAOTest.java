package com.cg.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;

public class DAOTest {
	@Test
	void testAddCustomer() {
		String name = "Thenmozhi";
		long mobNo = 99637;
		long accNo = 12345;
		double balance = 500.00;
		Account createAccObj = new Account(accNo, name, mobNo, balance);
		AccountDAO daoObj = new AccountDAO();
		
		assertEquals(1, daoObj.addCustomer(createAccObj));
	}

}
