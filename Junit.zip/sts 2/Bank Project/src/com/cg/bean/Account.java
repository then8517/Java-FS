package com.cg.bean;

public class Account {
	private long accNo = 0;
	private long sourceAccountNo, destAccountNo;
	private double balance;
	private String name;
	private long mobNo;
	
	public Account(){
		super();
	}
	
	public Account(long accNo, String name, long mobNo, double balance) {
		this.accNo = accNo;
		this.name = name;
		this.mobNo = mobNo;
		this.balance = balance;
	}
	
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public long getSourceAccountNo() {
		return sourceAccountNo;
	}
	public void setSourceAccountNo(long sourceAccountNo) {
		this.sourceAccountNo = sourceAccountNo;
	}
	public long getDestAccountNo() {
		return destAccountNo;
	}
	public void setDestAccountNo(long destAccountNo) {
		this.destAccountNo = destAccountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public long getMobNo() {
		return mobNo;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	
}
