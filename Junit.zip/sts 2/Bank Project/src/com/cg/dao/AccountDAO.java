package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Account;

public class AccountDAO {
	Account beanObj;
	HashMap<Long, Account> daoMap = new HashMap<Long, Account>();
	public int addCustomer(Account beanObj) {
		this.beanObj = beanObj;
		daoMap.put(beanObj.getAccNo(), beanObj);
		return 1;
	}
	public HashMap <Long, Account> list(){
		return daoMap;
	}
}
