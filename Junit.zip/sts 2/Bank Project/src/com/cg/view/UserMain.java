package com.cg.view;

import java.util.Scanner;

public class UserMain {

	public static void main(String[] args) {
		BankOperations bankObj = new BankOperations();
		Scanner scan = new Scanner(System.in);
		int i;
		System.out.println("Welcome \n Choose your option");
		do {
			System.out.println("1. Open Account \n2. Check Balance \n3. Transfer Amount \n4. Withdraw Amount ");
			i = scan.nextInt();
			switch(i) {
			case 1:{
				bankObj.createAccount();
				break;
			}
			case 2:{
				bankObj.checkBalance();
				break;
			}
			case 3:{
				bankObj.transferAmount();
				break;
			}
			case 4:{
				bankObj.withdrawAmount();
				break;
			}
			}

		}while(i != 4);
		
	}

}
