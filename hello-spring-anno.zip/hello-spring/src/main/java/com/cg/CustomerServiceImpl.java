package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	@Qualifier(value = "jdbcRepo")
	private CustomerRepository repo;

	public CustomerServiceImpl() {

//		repo = new JDBCCustomerRepositoryImpl();

	}

	public CustomerServiceImpl(CustomerRepository repository) {
		System.out.println("repository injected into service via constructor injection");
		repo = new JDBCCustomerRepositoryImpl();
	}

	public void setRepository(CustomerRepository repository) {
		System.out.println("repository injected into service via setter injection#1");
		this.repo = repository;
	}

	public void setRepository2(CustomerRepository repository) {
		System.out.println("repository injected into service via setter injection#2");
		this.repo = repository;
	}
	
	
	@Override
	public String find(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
